/**
 * ProcureAI background service worker.
 * Handles requests from the content script that require privileged Chrome APIs
 * (e.g. reading localStorage from a vendor tab using chrome.scripting).
 */

/**
 * Read a localStorage key from the first open tab matching urlPattern.
 * Returns null if no matching tab is open or the key is absent.
 */
async function queryTabsByUrlPatterns(urlPattern) {
  const patterns = Array.isArray(urlPattern) ? urlPattern : [urlPattern];
  const byId = new Map();
  for (const pattern of patterns.filter(Boolean)) {
    const tabs = await chrome.tabs.query({ url: pattern });
    for (const tab of tabs) {
      if (tab?.id !== undefined) byId.set(tab.id, tab);
    }
  }
  return Array.from(byId.values());
}

async function readTabLocalStorage(urlPattern, key) {
  try {
    const tabs = await queryTabsByUrlPatterns(urlPattern);
    if (!tabs.length) return null;
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: (k) => localStorage.getItem(k),
      args: [key],
    });
    const val = results?.[0]?.result ?? null;
    if (val) {
      // Persist the discovered value for later use when tab is closed
      chrome.storage.local.set({ [key]: val }).catch(() => {});
    }
    return val;
  } catch {
    return null;
  }
}

function extractDeliveryEtaFromPage(vendor) {
  const normalize = (value) => String(value || "").replace(/\s+/g, " ").trim();
  const normalizeEta = (value) => {
    const text = normalize(value);
    const range = text.match(/\b(\d{1,3})\s*[-–]\s*(\d{1,3})\s*(?:minutes?|mins?|min)\b/i);
    if (range) return `${range[1]}-${range[2]} mins`;

    const numeric = text.match(/\b(\d{1,3})\s*(?:minutes?|mins?|min)\b/i);
    if (numeric) return `${numeric[1]} mins`;

    const hours = text.match(/\b(\d{1,2})\s*(?:hours?|hrs?)\b/i);
    if (hours) return `${hours[1]} hrs`;

    return text;
  };

  const rootText = normalize(document.body?.innerText || "");
  const candidates = [];

  const selectorSets = {
    BigBasket: [
      "[class*='delivery' i]",
      "[class*='eta' i]",
      "[data-testid*='delivery' i]",
      "header",
    ],
    Blinkit: [
      "[class*='delivery' i]",
      "[class*='eta' i]",
      "[data-testid*='delivery' i]",
      "header",
    ],
    Zepto: [
      "[class*='delivery' i]",
      "[class*='eta' i]",
      "[data-testid*='delivery' i]",
      "header",
    ],
    Instamart: [
      "[class*='delivery' i]",
      "[class*='eta' i]",
      "[data-testid*='delivery' i]",
      "header",
    ],
  };

  for (const selector of selectorSets[vendor] || selectorSets.Blinkit) {
    for (const node of Array.from(document.querySelectorAll(selector)).slice(0, 20)) {
      const text = normalize(node.innerText || node.textContent || "");
      if (text) candidates.push(text);
    }
  }
  candidates.push(rootText);

  const patterns = [
    /\b\d{1,3}\s*[-–]\s*\d{1,3}\s*(?:minutes?|mins?|min)\b/i,
    /\bDelivery\s+in\s+\d{1,3}\s*(?:minutes?|mins?|min)\b/i,
    /\bDelivery\s+in\s+\d{1,2}\s*(?:hours?|hrs?)\b/i,
    /\b\d{1,3}\s*(?:minutes?|mins?|min)\s*(?:delivery|to deliver)\b/i,
  ];
  const vendorHeaderPatterns = {
    Zepto: [
      /\bdeliver(?:y|ing)?\s+in\s+\d{1,3}\s*(?:minutes?|mins?|min)\b/i,
      /⚡\s*\d{1,3}\s*(?:minutes?|mins?|min)\b/i,
    ],
  };

  for (const text of candidates) {
    for (const pattern of [...(vendorHeaderPatterns[vendor] || []), ...patterns]) {
      const match = text.match(pattern);
      if (match?.[0]) {
        return {
          eta: normalizeEta(match[0]),
          source: "live",
          matched_text: normalize(match[0]),
        };
      }
    }
  }

  return { eta: null, source: "unavailable" };
}

async function readTabDeliveryEta(urlPattern, vendor) {
  const patterns = Array.isArray(urlPattern) ? urlPattern.filter(Boolean) : [urlPattern].filter(Boolean);
  try {
    const tabs = await queryTabsByUrlPatterns(patterns);
    const tabSummaries = tabs.map((tab) => ({
      id: tab.id,
      url: tab.url || tab.pendingUrl || "",
      status: tab.status || "",
      active: Boolean(tab.active),
    }));
    if (!tabs.length) {
      return {
        eta: null,
        source: "unavailable",
        debug: { vendor, patterns, tabs_found: 0, tabs: [] },
      };
    }
    const tab =
      tabs.find((t) => t.status === "complete" && t.active) ||
      tabs.find((t) => t.status === "complete") ||
      tabs.find((t) => t.active) ||
      tabs[0];
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractDeliveryEtaFromPage,
      args: [vendor],
    });
    const result = results?.[0]?.result ?? null;
    const debug = {
      vendor,
      patterns,
      tabs_found: tabs.length,
      tabs: tabSummaries,
      selected_tab_id: tab.id,
      selected_tab_url: tab.url || tab.pendingUrl || "",
      selected_tab_status: tab.status || "",
      matched_text: result?.matched_text || null,
      extractor_source: result?.source || "unavailable",
    };
    return result?.eta
      ? { ...result, debug }
      : { eta: null, source: "unavailable", debug };
  } catch (err) {
    return {
      eta: null,
      source: "unavailable",
      debug: {
        vendor,
        patterns,
        error: err?.message || String(err),
      },
    };
  }
}

/**
 * Fetch a URL from the background service worker context.
 * Unlike content-script fetches, these don't carry an `Origin: http://localhost:...`
 * header, so vendor anti-bot checks (Amazon) are far less likely to trigger.
 * Returns { ok, status, text } or { error } on network failure.
 */
/**
 * Make an HTTP request from the background service worker context.
 * Background fetches bypass page-level CORS restrictions (host_permissions apply).
 * Supports GET and POST with custom headers and body.
 */
async function bgFetch(url, method = "GET", extraHeaders = {}, body = null, timeoutMs = 8000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const classifyFetchError = (status, text = "") => {
    const value = String(text || "").toLowerCase();
    if (/captcha|robot check|verify you are a human|automated access|unusual traffic/.test(value)) return "CAPTCHA";
    if (status === 401 || /\b(session expired|unauthori[sz]ed|authentication required|please login|please log in|sign in to continue|log in to continue|login required)\b/.test(value)) return "LOGIN_REQUIRED";
    if (status === 403 || status === 429 || /access denied|request blocked|temporarily blocked|forbidden|too many requests/.test(value)) return "BLOCKED";
    if (status === 404 || /\b(no results|no products found|sorry, no results|0 results)\b/.test(value)) return "NO_RESULTS";
    return "FETCH_ERROR";
  };
  try {
    const options = {
      method,
      credentials: "include",
      signal: controller.signal,
      headers: {
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-IN,en;q=0.9",
        ...extraHeaders,
      },
    };
    if (body !== null) options.body = body;
    const resp = await fetch(url, options);
    const text = await resp.text();
    clearTimeout(timer);
    return { ok: resp.ok, status: resp.status, url: resp.url, text, errorType: resp.ok ? null : classifyFetchError(resp.status, text) };
  } catch (e) {
    clearTimeout(timer);
    return { error: e.name === "AbortError" ? "timeout" : e.message, errorType: "FETCH_ERROR" };
  }
}

async function readDMartContext() {
  const cached = await chrome.storage.local.get(["dmartStoreId", "dmartDInfo"]).catch(() => ({}));
  try {
    const tabs = await chrome.tabs.query({ url: "https://www.dmart.in/*" });
    if (!tabs.length) {
      return { storeId: cached.dmartStoreId || "", dInfo: cached.dmartDInfo || "" };
    }
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: () => {
        const urls = performance.getEntriesByType("resource").map((entry) => entry.name);
        urls.push(location.href);
        let storeId = "";
        for (const url of urls) {
          const match = String(url).match(/[?&]storeId=([^&]+)/);
          if (match) {
            storeId = decodeURIComponent(match[1]);
            break;
          }
        }
        const cookies = Object.fromEntries(
          document.cookie.split("; ").filter(Boolean).map((cookie) => {
            const [key, ...rest] = cookie.split("=");
            return [key, decodeURIComponent(rest.join("=") || "")];
          })
        );
        return {
          storeId,
          dInfo: cookies.d_info || "",
          locationText: document.body?.innerText?.slice(0, 500) || "",
        };
      },
    });
    const context = results?.[0]?.result ?? {};
    if (context.storeId) {
      chrome.storage.local.set({ dmartStoreId: context.storeId }).catch(() => {});
    }
    if (context.dInfo) {
      chrome.storage.local.set({ dmartDInfo: context.dInfo }).catch(() => {});
    }
    return {
      storeId: context.storeId || cached.dmartStoreId || "",
      dInfo: context.dInfo || cached.dmartDInfo || "",
      locationText: context.locationText || "",
    };
  } catch {
    return { storeId: cached.dmartStoreId || "", dInfo: cached.dmartDInfo || "" };
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.action === "readLS") {
    readTabLocalStorage(message.urlPattern, message.key)
      .then((value) => sendResponse({ value }))
      .catch(() => sendResponse({ value: null }));
    return true; // keep channel open for async response
  }

  if (message.action === "readStorage") {
    chrome.storage.local.get([message.key], (res) => {
      sendResponse({ value: res[message.key] ?? null });
    });
    return true;
  }

  if (message.action === "writeStorage") {
    chrome.storage.local.set({ [message.key]: message.value }, () => {
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.action === "readDeliveryEta") {
    readTabDeliveryEta(message.urlPattern, message.vendor)
      .then((result) => sendResponse(result))
      .catch(() => sendResponse({ eta: null, source: "unavailable" }));
    return true;
  }

  if (message.action === "fetch") {
    bgFetch(message.url, message.method, message.headers ?? {}, message.body ?? null, message.timeoutMs ?? 8000)
      .then((result) => sendResponse(result))
      .catch(() => sendResponse({ error: "fetch failed" }));
    return true; // keep channel open for async response
  }

  if (message.action === "dmartContext") {
    readDMartContext()
      .then((context) => sendResponse(context))
      .catch(() => sendResponse({}));
    return true;
  }
});
