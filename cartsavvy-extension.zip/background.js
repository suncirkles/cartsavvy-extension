/**
 * ProcureAI background service worker.
 * Handles requests from the content script that require privileged Chrome APIs
 * (e.g. reading localStorage from a vendor tab using chrome.scripting).
 */

/**
 * Read a localStorage key from the first open tab matching urlPattern.
 * Returns null if no matching tab is open or the key is absent.
 */
async function readTabLocalStorage(urlPattern, key) {
  try {
    const tabs = await chrome.tabs.query({ url: urlPattern });
    if (!tabs.length) return null;
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: (k) => localStorage.getItem(k),
      args: [key],
    });
    return results?.[0]?.result ?? null;
  } catch {
    return null;
  }
}

/**
 * Fetch a URL from the background service worker context.
 * Unlike content-script fetches, these don't carry an `Origin: http://localhost:...`
 * header, so vendor anti-bot checks (Amazon) are far less likely to trigger.
 * Returns { ok, status, text } or { error } on network failure.
 */
/**
 * Make an HTTP request from the background service worker context.
 * Background fetches bypass page-level CORS restrictions (host_permissions apply).
 * Supports GET and POST with custom headers and body.
 */
async function bgFetch(url, method = "GET", extraHeaders = {}, body = null, timeoutMs = 8000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const options = {
      method,
      credentials: "include",
      signal: controller.signal,
      headers: {
        "Accept": "application/json, text/html, */*",
        "Accept-Language": "en-IN,en;q=0.9",
        ...extraHeaders,
      },
    };
    if (body !== null) options.body = body;
    const resp = await fetch(url, options);
    const text = await resp.text();
    clearTimeout(timer);
    return { ok: resp.ok, status: resp.status, text };
  } catch (e) {
    clearTimeout(timer);
    return { error: e.name === "AbortError" ? "timeout" : e.message };
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.action === "readLS") {
    readTabLocalStorage(message.urlPattern, message.key)
      .then((value) => sendResponse({ value }))
      .catch(() => sendResponse({ value: null }));
    return true; // keep channel open for async response
  }

  if (message.action === "fetch") {
    bgFetch(message.url, message.method, message.headers ?? {}, message.body ?? null)
      .then((result) => sendResponse(result))
      .catch(() => sendResponse({ error: "fetch failed" }));
    return true; // keep channel open for async response
  }
});
