/**
 * CartSavvy content script — injected into the CartSavvy frontend page.
 *
 * Protocol (window.postMessage):
 *   Page → extension : { type: "CARTSAVVY_FETCH_PRICES", queries: string[], requestId: string }
 *   Extension → page : { type: "CARTSAVVY_PRICES_RESULT", requestId: string,
 *                         grounding: { [query]: { [vendor]: [{title,price,mrp,url,inStock}] } } | null,
 *                         error?: string }
 *
 * The page detects extension presence via window.__cartsavvyExtension.
 */

// ── Background messaging helper (for privileged APIs) ────────────────────────

function _runtimeAvailable() {
  return Boolean(globalThis.chrome?.runtime?.sendMessage);
}

function _sendRuntimeMessage(message) {
  return new Promise((resolve, reject) => {
    if (!_runtimeAvailable()) {
      reject(new Error("Extension runtime unavailable; reload the CartSavvy tab after reloading the extension"));
      return;
    }
    try {
      chrome.runtime.sendMessage(message, (resp) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(resp);
      });
    } catch (err) {
      reject(err);
    }
  });
}

async function _bgReadLS(urlPattern, key) {
  return new Promise((resolve) => {
    // 1. Try to read from an open tab first (freshest data)
    _sendRuntimeMessage({ action: "readLS", urlPattern, key })
      .then((resp) => {
        if (resp?.value) {
          resolve(resp.value);
          return;
        }
        // 2. Fallback to persisted storage from background service worker
        return _sendRuntimeMessage({ action: "readStorage", key })
          .then((sResp) => resolve(sResp?.value ?? null))
          .catch(() => resolve(null));
      })
      .catch(() => resolve(null));
  });
}

async function _bgReadDeliveryEta(urlPattern, vendor) {
  return new Promise((resolve) => {
    _sendRuntimeMessage({ action: "readDeliveryEta", urlPattern, vendor })
      .then((resp) => {
        if (resp?.eta) {
          resolve({
            eta: String(resp.eta).replace(/\s+/g, " ").trim(),
            debug: resp,
          });
          return;
        }
        resolve({ eta: null, debug: resp ?? null });
      })
      .catch((err) => resolve({ eta: null, debug: { error: err?.message || String(err) } }));
  });
}

async function _preferOpenTabEta(urlPattern, vendor, currentEta, currentSource) {
  if (currentSource !== "est") return { vendor_eta: currentEta, eta_source: currentSource, eta_debug: null };
  const liveEta = await _bgReadDeliveryEta(urlPattern, vendor);
  if (liveEta.eta) {
    return { vendor_eta: liveEta.eta, eta_source: "live", eta_debug: liveEta.debug };
  }
  return { vendor_eta: currentEta, eta_source: currentSource, eta_debug: liveEta.debug };
}

function _safeParseJSON(text, vendor, query) {
  if (!text) {
    throw new Error(`Empty response from ${vendor}`);
  }
  try {
    return JSON.parse(text);
  } catch (e) {
    console.error(`[${vendor}] JSON Parse failed for query: ${query}`);
    console.error(`[${vendor}] Raw response snippet:`, text.slice(0, 200));
    // Propagate more descriptive error for the UI
    if (text.trim().startsWith("<!DOCTYPE html") || text.trim().startsWith("<html")) {
      throw new Error(`Received HTML instead of JSON from ${vendor} (likely session expired or bot block)`);
    }
    throw new Error(`Malformed JSON from ${vendor}: ${e.message}`);
  }
}

function _cleanQuery(q) {
  return String(q || "")
    .replace(/\b(\d+)\s*(?:kg|g|gm|ml|l|ltr|litre|litres)\b/gi, "")
    .replace(/\bpack\s+of\s+\d+\b/gi, "")
    .replace(/\b(?:x|qty|quantity)\s*\d+\b/gi, "")
    .replace(/\s+/g, " ")
    .trim();
}

function _sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function _fetchJsonWithRetry(url, vendor, query, attempts = 2) {
  let lastError = null;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const text = await _bgFetch(url);
    try {
      return _safeParseJSON(text, vendor, query);
    } catch (err) {
      lastError = err;
      if (attempt < attempts - 1) await _sleep(250);
    }
  }
  throw lastError;
}

function _asArray(value) {
  if (Array.isArray(value)) return value;
  if (!value || typeof value !== "object") return [];
  if (value.item || value.variations) return [value];
  return Object.values(value).filter((entry) => entry && typeof entry === "object");
}

function _normalizeText(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

function _parseMoney(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  if (value && typeof value === "object") {
    return _parseMoney(
      value.value ?? value.amount ?? value.price ?? value.displayValue ?? value.text ?? value.raw
    );
  }
  const match = String(value ?? "").replace(/,/g, "").match(/(?:rs\.?|inr|₹)?\s*(\d+(?:\.\d+)?)/i);
  return match ? parseFloat(match[1]) : 0;
}

function _absoluteUrl(rawUrl, baseUrl) {
  const text = String(rawUrl ?? "").trim();
  if (!text) return "";
  if (/^data:/i.test(text)) return "";
  if (text.startsWith("//")) return "https:" + text;
  if (/^https?:\/\//i.test(text)) return text;
  try {
    return new URL(text, baseUrl).toString();
  } catch {
    return text;
  }
}

function _firstSrcsetUrl(value) {
  const text = String(value ?? "").trim();
  if (!text) return "";
  return text.split(",")[0]?.trim().split(/\s+/)[0] || "";
}

function _imageUrlFromElement(img, baseUrl) {
  if (!img) return "";
  const raw = _firstTruthy(
    img.currentSrc,
    img.src,
    img.dataset?.src,
    img.dataset?.original,
    img.dataset?.lazySrc,
    img.dataset?.image,
    img.getAttribute?.("data-src"),
    img.getAttribute?.("data-original"),
    img.getAttribute?.("data-lazy-src"),
    img.getAttribute?.("data-image"),
    _firstSrcsetUrl(img.srcset),
    _firstSrcsetUrl(img.dataset?.srcset),
    _firstSrcsetUrl(img.getAttribute?.("srcset")),
    _firstSrcsetUrl(img.getAttribute?.("data-srcset")),
  );
  if (raw) return _absoluteUrl(raw, baseUrl);

  const background = img.style?.backgroundImage || img.getAttribute?.("style") || "";
  const match = String(background).match(/url\(["']?([^"')]+)["']?\)/i);
  return _absoluteUrl(match?.[1], baseUrl);
}

function _firstTruthy(...values) {
  for (const value of values) {
    if (value !== null && value !== undefined && String(value).trim() !== "") return value;
  }
  return null;
}

function _firstMatch(text, patterns) {
  const value = String(text ?? "");
  for (const pattern of patterns) {
    const match = value.match(pattern);
    if (match?.[1]) return _normalizeText(match[1]);
    if (match?.[0]) return _normalizeText(match[0]);
  }
  return null;
}

function _truthyStock(value, fallback = true) {
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value > 0;
  if (value && typeof value === "object") {
    return _truthyStock(value.value ?? value.text ?? value.status ?? value.available, fallback);
  }
  const text = String(value ?? "").trim().toLowerCase();
  if (!text) return fallback;
  if (/(out of stock|currently unavailable|sold out|unavailable|notify me)/i.test(text)) return false;
  if (/(in stock|add to cart|add to bag|available|buy now)/i.test(text)) return true;
  return fallback;
}

function _vendorError(type, vendor, message) {
  const err = new Error(`${type}: ${message}`);
  err.errorType = type;
  err.vendor = vendor;
  return err;
}

function _classifyVendorError(value) {
  const text = String(value?.message ?? value ?? "").toLowerCase();
  if (/captcha|robot|verify you|automated|unusual traffic/.test(text)) return "CAPTCHA";
  if (/\b(http 401|session expired|unauthori[sz]ed|authentication required|please login|please log in|sign in to continue|log in to continue|login required)\b/.test(text)) return "LOGIN_REQUIRED";
  if (/blocked|access denied|forbidden|http 403|too many requests|http 429/.test(text)) return "BLOCKED";
  if (/no results|no matching|not found/.test(text)) return "NO_RESULTS";
  if (/parse|parser|malformed|unexpected html|selector/.test(text)) return "PARSER_ERROR";
  return "FETCH_ERROR";
}

function _detectMarketplaceError(html, doc, vendor) {
  const text = _normalizeText(doc?.body?.innerText || html).slice(0, 20000);
  if (/captcha|robot check|verify you are a human|automated access|unusual traffic/i.test(text)) {
    return _vendorError("CAPTCHA", vendor, `${vendor} returned a captcha or robot-check page`);
  }
  if (/access denied|request blocked|temporarily blocked|forbidden|too many requests/i.test(text)) {
    return _vendorError("BLOCKED", vendor, `${vendor} blocked the marketplace search request`);
  }
  if (/\b(session expired|unauthori[sz]ed|authentication required|please login|please log in|sign in to continue|log in to continue|login required)\b/i.test(text)) {
    return _vendorError("LOGIN_REQUIRED", vendor, `${vendor} requires a signed-in browser session`);
  }
  if (/\b(no results|no products found|sorry, no results|0 results)\b/i.test(text)) {
    return _vendorError("NO_RESULTS", vendor, `${vendor} returned no search results`);
  }
  return null;
}

function _parseScriptJsonObjects(doc) {
  const objects = [];
  for (const script of Array.from(doc.querySelectorAll("script")).slice(0, 120)) {
    const text = script.textContent || "";
    const trimmed = text.trim();
    if (!trimmed) continue;
    if (script.type === "application/ld+json" || /^[\[{]/.test(trimmed)) {
      try {
        objects.push(JSON.parse(trimmed));
        continue;
      } catch {}
    }
    for (const pattern of [
      /__NEXT_DATA__\s*=\s*({[\s\S]*?})\s*<\/script>/i,
      /window\.__INITIAL_STATE__\s*=\s*({[\s\S]*?});/i,
      /window\.__PRELOADED_STATE__\s*=\s*({[\s\S]*?});/i,
    ]) {
      const match = text.match(pattern);
      if (!match?.[1]) continue;
      try {
        objects.push(JSON.parse(match[1]));
      } catch {}
    }
  }
  return objects;
}

function _walkObjects(root, visit, seen = new Set(), depth = 0) {
  if (!root || typeof root !== "object" || depth > 12 || seen.has(root)) return;
  seen.add(root);
  visit(root);
  if (Array.isArray(root)) {
    for (const child of root) _walkObjects(child, visit, seen, depth + 1);
    return;
  }
  for (const child of Object.values(root)) {
    if (child && typeof child === "object") _walkObjects(child, visit, seen, depth + 1);
  }
}

function _extractBeautyMetadata(source, text = "") {
  const haystack = _normalizeText([
    text,
    source?.title,
    source?.name,
    source?.subtitle,
    source?.variant,
    source?.variantName,
    source?.shade,
    source?.shadeName,
    source?.packSize,
    source?.size,
    source?.displaySize,
  ].filter(Boolean).join(" "));
  const lower = haystack.toLowerCase();
  const metadata = {};
  const direct = {
    shade: source?.shade ?? source?.shadeName ?? source?.color ?? source?.colour,
    shade_family: source?.shadeFamily ?? source?.shade_family ?? source?.colorFamily,
    skin_type: source?.skinType ?? source?.skin_type,
    hair_type: source?.hairType ?? source?.hair_type,
    finish: source?.finish,
    concern: source?.concern ?? source?.benefit,
    form: source?.form ?? source?.productForm,
    variant: source?.variant ?? source?.variantName ?? source?.displaySize ?? source?.packSize ?? source?.size,
  };
  for (const [key, value] of Object.entries(direct)) {
    const normalized = _normalizeText(value);
    if (normalized) metadata[key] = normalized;
  }
  const spf = _firstMatch(haystack, [/\bspf\s*([0-9]{2,3}\+?)\b/i]);
  if (spf) metadata.spf = spf.replace(/^spf\s*/i, "");
  const pack = _firstMatch(haystack, [
    /\b(pack\s+of\s+\d+)\b/i,
    /\b(\d+\s*x\s*\d+(?:\.\d+)?\s*(?:ml|g|gm|kg|l|oz))\b/i,
    /\b(\d+(?:\.\d+)?\s*(?:ml|g|gm|kg|l|oz))\b/i,
  ]);
  if (pack) {
    metadata.pack_size_text = pack;
    metadata.variant = metadata.variant || pack;
    const count = pack.match(/\bpack\s+of\s+(\d+)\b/i) || pack.match(/\bx\s*(\d+)\b/i);
    if (count) metadata.pack_count = parseInt(count[1], 10);
  }
  if (!metadata.skin_type) {
    const skin = lower.match(/\b(oily|dry|combination|sensitive|normal|acne prone|all skin types)\s+skin\b/i);
    if (skin) metadata.skin_type = _normalizeText(skin[0]);
  }
  if (!metadata.hair_type) {
    const hair = lower.match(/\b(curly|wavy|straight|dry|frizzy|damaged|colou?red|all hair types)\s+hair\b/i);
    if (hair) metadata.hair_type = _normalizeText(hair[0]);
  }
  if (!metadata.finish) {
    const finish = lower.match(/\b(matte|dewy|glossy|natural|satin|radiant|luminous)\s+finish\b/i);
    if (finish) metadata.finish = _normalizeText(finish[0]);
  }
  if (!metadata.form) {
    const form = lower.match(/\b(cream|serum|gel|lotion|spray|stick|powder|liquid|balm|oil|mask|shampoo|conditioner)\b/i);
    if (form) metadata.form = _normalizeText(form[1]);
  }
  if (!metadata.concern) {
    const concern = lower.match(/\b(acne|pigmentation|dark spots|dandruff|hair fall|frizz|anti ageing|anti-aging|sun protection|hydration)\b/i);
    if (concern) metadata.concern = _normalizeText(concern[1]);
  }
  return metadata;
}

function _normalizeBeautyProduct(vendor, raw) {
  const title = _normalizeText(_firstTruthy(raw.title, raw.name, raw.productName, raw.product_name));
  const price = _parseMoney(_firstTruthy(raw.price, raw.sellingPrice, raw.salePrice, raw.finalPrice, raw.discountedPrice));
  const mrp = _parseMoney(_firstTruthy(raw.mrp, raw.listPrice, raw.originalPrice, raw.strikedPrice, raw.maximumRetailPrice)) || price;
  const url = _absoluteUrl(_firstTruthy(raw.url, raw.product_url, raw.productUrl, raw.actionUrl, raw.link), raw.baseUrl);
  const imageUrl = _absoluteUrl(_firstTruthy(raw.image_url, raw.imageUrl, raw.image, raw.imageURL, raw.thumbnail, raw.img), raw.baseUrl);
  const inStock = _truthyStock(_firstTruthy(raw.inStock, raw.in_stock, raw.available, raw.availability, raw.stock, raw.status), true);
  const allowUnknownPrice = raw.allow_unknown_price === true;
  if (!title || (!price && inStock && !allowUnknownPrice)) return null;
  const product = {
    title,
    price,
    mrp: mrp || price,
    price_unknown: !price,
    url,
    product_url: url,
    image_url: imageUrl,
    inStock,
    in_stock: inStock,
    sku_id: _normalizeText(_firstTruthy(raw.sku_id, raw.skuId, raw.sku, raw.id, raw.listingId)),
    product_id: _normalizeText(_firstTruthy(raw.product_id, raw.productId, raw.pid, raw.id)),
    asin: _normalizeText(raw.asin),
    promo_tag: _normalizeText(_firstTruthy(raw.promo_tag, raw.promo, raw.offer, raw.discount, raw.badge)) || null,
    bank_offer: _normalizeText(_firstTruthy(raw.bank_offer, raw.bank, raw.bankOffer)) || null,
    prime: raw.prime ?? raw.is_prime ?? null,
    source: `extension_${vendor.toLowerCase().replace(/[^a-z0-9]+/g, "_")}`,
    score: _scoreMatch(raw.query, title),
    ..._extractBeautyMetadata(raw, title),
  };
  if (vendor === "Amazon.in" && product.asin && !product.product_id) product.product_id = product.asin;
  return product;
}

function _collectZeptoItems(data) {
  const direct = _asArray(data?.data?.items);
  if (direct.length) return direct;

  const items = [];
  for (const widget of _asArray(data?.layout)) {
    items.push(..._asArray(widget?.data?.resolver?.data?.items ?? widget?.data?.items));
  }
  return items;
}

function _findEtaText(value, depth = 0) {
  if (depth > 8 || value === null || value === undefined) return null;
  if (typeof value === "string") {
    const text = value.replace(/\s+/g, " ").trim();
    return /\b\d{1,3}\s*(?:minutes?|mins?|min)\b/i.test(text) ? text : null;
  }
  if (typeof value !== "object") return null;

  const priorityKeys = [
    "deliveryTime",
    "delivery_time",
    "eta",
    "etaText",
    "eta_text",
    "estimatedDeliveryTime",
    "estimated_delivery_time",
    "displayText",
  ];
  for (const key of priorityKeys) {
    const found = _findEtaText(value[key], depth + 1);
    if (found) return found;
  }
  for (const child of Object.values(value)) {
    const found = _findEtaText(child, depth + 1);
    if (found) return found;
  }
  return null;
}

/**
 * Make a request via the background service worker.
 * Background fetches have extension-level host permissions and bypass page CORS.
 * Returns response text, or throws on network error / non-OK status.
 */
async function _bgFetch(url, options = {}, timeoutMs = 10000) {
  const resp = await _bgFetchResponse(url, options, timeoutMs);
  return resp.text;
}

async function _bgFetchResponse(url, options = {}, timeoutMs = 10000) {
  const bgPromise = new Promise((resolve, reject) => {
    _sendRuntimeMessage({
      action: "fetch",
      url,
      method: options.method ?? "GET",
      headers: options.headers ?? {},
      body: options.body ?? null,
      timeoutMs,
    })
      .then((resp) => {
        if (resp?.error) {
          const err = new Error(resp.error);
          err.errorType = resp.errorType || _classifyVendorError(resp.error);
          reject(err);
          return;
        }
        if (!resp?.ok) {
          const err = new Error("HTTP " + resp?.status);
          err.errorType = resp?.errorType || _classifyVendorError(err);
          reject(err);
          return;
        }
        resolve(resp);
      })
      .catch(reject);
  });
  const timeoutPromise = new Promise((_, reject) =>
    setTimeout(() => reject(new Error("bgFetch timeout")), timeoutMs)
  );
  return Promise.race([bgPromise, timeoutPromise]);
}

async function _dmartContext() {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ action: "dmartContext" }, (resp) => {
        if (chrome.runtime.lastError) {
          resolve({});
          return;
        }
        resolve(resp ?? {});
      });
    } catch {
      resolve({});
    }
  });
}


// ── Vendor fetchers ───────────────────────────────────────────────────────────

async function fetchBigBasket(query) {
  const urlFor = (q) =>
    "https://www.bigbasket.com/listing-svc/v2/products?" +
    "type=ps&slug=" + encodeURIComponent(q) + "&page=1&bucket_id=52";
  const fetchData = (q) => _fetchJsonWithRetry(urlFor(q), "BigBasket", q);

  let data;
  try {
    data = await fetchData(query);
  } catch (err) {
    const cleaned = _cleanQuery(query);
    if (!cleaned || cleaned === query) throw err;
    data = await fetchData(cleaned);
  }

  const getProducts = (d) => {
    const base = d?.tabs?.[0]?.product_info?.products ?? [];
    const flattened = [];
    for (const p of base) {
      flattened.push(p);
      if (Array.isArray(p.children)) {
        for (const child of p.children) {
          // Merge parent info into child so mapping works (desc, w, pricing, etc.)
          flattened.push({ ...p, ...child, children: null });
        }
      }
    }
    return flattened;
  };
  let raw = getProducts(data);
  if (!raw.length) {
    const cleaned = _cleanQuery(query);
    if (cleaned && cleaned !== query) {
      data = await fetchData(cleaned);
      raw = getProducts(data);
    }
  }

  // ETA: BigBasket now has q-commerce. The API returns delivery_time or slot_type
  // at the tab or product_info level; check several known field locations.
  const tab0 = data?.tabs?.[0] ?? {};
  const etaRaw =
    tab0.delivery_time ??
    tab0.slot_type ??
    data?.delivery_time ??
    tab0.product_info?.delivery_time ??
    null;
  let vendor_eta = etaRaw ? String(etaRaw) : "Express";
  let eta_source = etaRaw ? "live" : "est";
  let eta_debug = null;
  ({ vendor_eta, eta_source, eta_debug } = await _preferOpenTabEta(["*://bigbasket.com/*", "*://*.bigbasket.com/*"], "BigBasket", vendor_eta, eta_source));

  const products = raw
    .map((p) => {
      const image = Array.isArray(p.images) ? (p.images[0] || {}) : (p.images || {});
      const pack = p.w ?? "";
      const title = [p.desc ?? "", pack].filter(Boolean).join(" ").trim();
      return {
        title,
        price: parseFloat(p.pricing?.discount?.prim_price?.sp ?? 0),
        mrp: parseFloat(p.pricing?.discount?.mrp ?? 0),
        url: "https://www.bigbasket.com" + (p.absolute_url ?? ""),
        image_url: image.m ?? image.s ?? image.url ?? "",
        inStock: p.availability?.button === "Add",
        promo_tag: p.badges?.[0]?.text ?? p.ribbon_text ?? null,
        bank_offer: p.offers?.[0]?.description ?? p.bank_offers?.[0]?.text ?? null,
        pack_size_text: pack,
        w: pack,
        unit: p.unit ?? p.pricing?.discount?.prim_price?.base_unit ?? "",
      };
    })
    .filter((p) => p.price > 0)
    .map((p) => ({ ...p, score: _scoreMatch(query, p.title) }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);

  return { products, vendor_eta, eta_source, eta_debug };
}

function _dmartNumber(value) {
  if (value === null || value === undefined) return 0;
  const parsed = parseFloat(String(value).replace(/[^0-9.]/g, ""));
  return Number.isFinite(parsed) ? parsed : 0;
}

function _dmartImageUrl(product, sku) {
  const key = sku?.productImageKey ?? sku?.imageKey ?? product?.productImageKey ?? product?.productImageKeyWeb;
  const code = sku?.imgCode ?? sku?.binaryImgCode ?? product?.imgCode ?? product?.imageCode;
  if (key && code) {
    return `https://cdn.dmart.in/images/products/${key}_${code}_B.jpg`;
  }
  const raw = product?.imageUrl ?? product?.image_url ?? product?.image;
  if (!raw) return "";
  if (String(raw).startsWith("http")) return String(raw);
  return `https://cdn.dmart.in/${String(raw).replace(/^\/+/, "")}`;
}

function _dmartProductUrl(product, sku, query) {
  const slug = String(product?.seo_token_ntk ?? product?.seoToken ?? "").trim();
  const skuId = String(sku?.skuUniqueID ?? sku?.skuId ?? "").trim();
  if (slug && skuId) {
    return `https://www.dmart.in/product/${encodeURIComponent(slug)}?selectedProd=${encodeURIComponent(skuId)}`;
  }
  return `https://www.dmart.in/search?searchTerm=${encodeURIComponent(query)}`;
}

function _dmartInStock(product, sku) {
  const markers = [
    product?.buyable,
    sku?.buyable,
    product?.inStock,
    sku?.inStock,
    product?.available,
    sku?.available,
    product?.availabilityType,
    sku?.availabilityType,
    sku?.invStatus,
  ];
  for (const marker of markers) {
    const value = String(marker ?? "").trim().toLowerCase();
    if (!value) continue;
    if (["false", "0", "no", "n", "out_of_stock", "out of stock", "unavailable", "sold out"].includes(value)) {
      return false;
    }
  }
  return true;
}

function _dmartQuantityInfo(text) {
  const value = String(text || "").toLowerCase();
  const info = { total: null, unit_type: null, pack_count: null };
  const unitScale = {
    kg: ["weight", 1000],
    kgs: ["weight", 1000],
    g: ["weight", 1],
    gm: ["weight", 1],
    gms: ["weight", 1],
    l: ["volume", 1000],
    lt: ["volume", 1000],
    ltr: ["volume", 1000],
    litre: ["volume", 1000],
    liter: ["volume", 1000],
    ml: ["volume", 1],
  };
  const packMatch = value.match(/\bpack\s+of\s+(\d+)\b/);
  if (packMatch) info.pack_count = parseInt(packMatch[1], 10);

  const xAfter = value.match(/\b(\d+(?:\.\d+)?)\s*(kg|kgs|g|gm|gms|l|lt|ltr|litre|liter|ml)\s*x\s*(\d+)\b/i);
  const xBefore = value.match(/\b(\d+)\s*x\s*(\d+(?:\.\d+)?)\s*(kg|kgs|g|gm|gms|l|lt|ltr|litre|liter|ml)\b/i);
  if (xAfter || xBefore) {
    const qty = parseFloat(xAfter ? xAfter[1] : xBefore[2]);
    const unit = (xAfter ? xAfter[2] : xBefore[3]).toLowerCase();
    const count = parseInt(xAfter ? xAfter[3] : xBefore[1], 10);
    const scale = unitScale[unit];
    if (scale && Number.isFinite(qty) && Number.isFinite(count)) {
      info.unit_type = scale[0];
      info.total = qty * scale[1] * count;
      info.pack_count = count;
      return info;
    }
  }

  const qtyMatch = value.match(/\b(\d+(?:\.\d+)?)\s*(kg|kgs|g|gm|gms|l|lt|ltr|litre|liter|ml)\b/i);
  if (qtyMatch) {
    const qty = parseFloat(qtyMatch[1]);
    const scale = unitScale[qtyMatch[2].toLowerCase()];
    if (scale && Number.isFinite(qty)) {
      info.unit_type = scale[0];
      info.total = qty * scale[1] * (info.pack_count || 1);
    }
  }
  return info;
}

function _dmartWithQuantityMetadata(query, product) {
  const requested = _dmartQuantityInfo(query);
  const candidate = _dmartQuantityInfo(`${product?.title || ""} ${product?.pack_size_text || ""}`);
  const enriched = { ...product };

  if (requested.total && candidate.total && requested.unit_type === candidate.unit_type) {
    enriched.quantity_gap_ratio = Math.abs(requested.total - candidate.total) / requested.total;
  }
  if (candidate.total && candidate.unit_type) {
    enriched.pack_quantity = candidate.total;
    enriched.pack_unit = candidate.unit_type === "weight" ? "g" : "ml";
    enriched.unit_class = candidate.unit_type;
  }

  if (requested.pack_count) {
    enriched.requested_pack_count = requested.pack_count;
  }
  if (candidate.pack_count) {
    enriched.pack_count = candidate.pack_count;
  }

  return enriched;
}

async function fetchDMart(query) {
  const context = await _dmartContext();
  const storeId = String(context?.storeId ?? "").trim();
  const params = new URLSearchParams({
    page: "1",
    buryOOS: "true",
    size: "100",
    channel: "web",
  });
  if (storeId) params.set("storeId", storeId);
  const url = "https://digital.dmart.in/api/v3/search/" + encodeURIComponent(query) + "?" + params.toString();
  const headers = {
    accept: "application/json, text/plain, */*",
    origin: "https://www.dmart.in",
    referer: "https://www.dmart.in/",
  };
  if (storeId) headers.storeid = storeId;
  if (context?.dInfo) headers.d_info = context.dInfo;
  const text = await _bgFetch(url, {
    headers,
  });
  const data = _safeParseJSON(text, "DMart", query);
  const rawProducts = data?.products ?? data?.productList ?? data?.data?.products ?? [];
  const products = [];

  for (const product of rawProducts) {
    const skus = Array.isArray(product?.sKUs)
      ? product.sKUs
      : (Array.isArray(product?.skus) ? product.skus : [product]);
    for (const sku of skus) {
      const title = String(sku?.name ?? product?.name ?? "").replace(/\s+/g, " ").trim();
      const price = _dmartNumber(sku?.priceSALE ?? sku?.sellingPrice ?? sku?.price ?? product?.priceSALE);
      if (!title || price <= 0) continue;
      products.push({
        title,
        price,
        mrp: _dmartNumber(sku?.priceMRP ?? sku?.mrp ?? sku?.priceMRPValue ?? product?.priceMRP) || price,
        url: _dmartProductUrl(product, sku, query),
        image_url: _dmartImageUrl(product, sku),
        inStock: _dmartInStock(product, sku),
        promo_tag: product?.productAnnouncement?.[0]?.tagName ?? product?.offerText ?? null,
        bank_offer: null,
        pack_size_text: sku?.variantTextValue ?? sku?.variantInfoTxtValue ?? "",
        sku_id: String(sku?.skuUniqueID ?? sku?.articleNumber ?? ""),
        product_id: String(product?.productId ?? ""),
        source: "extension_dmart_api",
      });
    }
    if (products.length >= 40) break;
  }

  return {
    products: products.map((product) => _dmartWithQuantityMetadata(query, product)).slice(0, 10),
    vendor_eta: null,
    eta_source: "unavailable",
  };
}


/**
 * Parse a delivery ETA string from an Amazon search results page DOM.
 * Returns the ETA string if found (e.g. "Delivery in 2 hours", "Get it by Today"),
 * or null if the pincode is not set / ETA not present.
 * Uses only the already-fetched HTML — no extra network request.
 */
function _parseAmazonIsPrime(doc) {
  // Check inline data first — fastest and most reliable
  for (const script of doc.querySelectorAll("script")) {
    const t = script.textContent;
    if (/"isPrimeMember"\s*:\s*true/.test(t) || /isPrimeMember=true/.test(t)) return true;
    if (/"isPrimeMember"\s*:\s*false/.test(t) || /isPrimeMember=false/.test(t)) return false;
  }
  // Fallback: Prime nav button or badge present in header
  if (doc.querySelector("#nav-prime-btn, .nav-prime, .huc-amazon-prime-text")) return true;
  // Cannot determine — return null so the backend doesn't assume non-prime
  return null;
}

function _parseAmazonEta(doc) {
  // Try 1: success-colored delivery text near the top of the page
  for (const el of doc.querySelectorAll(".a-color-success, .a-color-base")) {
    const t = el.textContent.trim();
    if (/\b(delivery|get it|arrives?|dispatch)\b/i.test(t) &&
      /\b(min|hour|today|tomorrow|\d+\s*hr)/i.test(t)) {
      return t.replace(/\s+/g, " ").slice(0, 60);
    }
  }
  // Try 2: any text node matching a delivery-time pattern
  const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
  const pat = /delivery in \d+[\s\w]+|get it by .{3,40}|arrives? .{3,40}/i;
  let node;
  while ((node = walker.nextNode())) {
    const t = node.textContent.trim();
    const m = t.match(pat);
    if (m) return m[0].replace(/\s+/g, " ").slice(0, 60);
  }
  return null;
}

async function fetchAmazonFresh(query) {
  const url = "https://www.amazon.in/s?k=" + encodeURIComponent(query) + "&i=nowstore";
  const html = await _bgFetch(url);

  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const cards = doc.querySelectorAll('[data-component-type="s-search-result"]');

  // ETA + Prime: parse from already-fetched HTML (pincode must be set in user's session)
  const etaRaw = _parseAmazonEta(doc);
  const vendor_eta = etaRaw ?? "2–4 hrs";
  const eta_source = etaRaw ? "live" : "est";
  const is_prime = _parseAmazonIsPrime(doc);

  const products = [];
  for (const card of cards) {
    if (card.textContent.toLowerCase().includes("sponsored")) continue;
    const asin = card.dataset.asin ?? "";

    const titleEl =
      card.querySelector('[data-cy="title-recipe"]') ?? card.querySelector("h2");
    const title = titleEl ? titleEl.textContent.replace(/\s+/g, " ").trim() : "";
    if (!title || /combo|bundle/i.test(title)) continue;
    if (card.textContent.toLowerCase().includes("currently unavailable")) continue;

    const priceEl = card.querySelector("span.a-price-whole");
    if (!priceEl) continue;
    const price = parseFloat(priceEl.textContent.replace(/[^\d.]/g, ""));
    if (!price) continue;

    const imgEl = card.querySelector("img.s-image");
    products.push({
      title,
      price,
      mrp: price,
      url: asin ? "https://www.amazon.in/dp/" + asin + "?almBrandId=ctnow&fpw=alm" : "",
      image_url: imgEl?.src ?? imgEl?.dataset?.src ?? "",
      inStock: true,
      promo_tag: null,   // Amazon search page has no promo badges
      bank_offer: null,   // Amazon bank offers shown on product page, not in search
      score: _scoreMatch(query, title),
    });
    if (products.length >= 5) break;
  }

  if (!products.length && /captcha|robot check/i.test(html)) {
    throw new Error("CAPTCHA");
  }
  return { products: products.sort((a,b)=>b.score - a.score), vendor_eta, eta_source, is_prime };
}


async function fetchAmazonNow(query) {
  const url = "https://www.amazon.in/s?k=" + encodeURIComponent(query) + "&i=amazontez";
  const html = await _bgFetch(url);

  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const cards = doc.querySelectorAll('[data-component-type="s-search-result"]');

  // ETA + Prime: parse from already-fetched HTML (pincode must be set in user's session)
  const etaRaw = _parseAmazonEta(doc);
  const vendor_eta = etaRaw ?? "2–4 hrs";
  const eta_source = etaRaw ? "live" : "est";
  const is_prime = _parseAmazonIsPrime(doc);

  const products = [];
  for (const card of cards) {
    if (card.textContent.toLowerCase().includes("sponsored")) continue;
    const asin = card.dataset.asin ?? "";

    const titleEl =
      card.querySelector('[data-cy="title-recipe"]') ?? card.querySelector("h2");
    const title = titleEl ? titleEl.textContent.replace(/\s+/g, " ").trim() : "";
    if (!title || /combo|bundle/i.test(title)) continue;
    if (card.textContent.toLowerCase().includes("currently unavailable")) continue;

    const priceEl = card.querySelector("span.a-price-whole");
    if (!priceEl) continue;
    const price = parseFloat(priceEl.textContent.replace(/[^\d.]/g, ""));
    if (!price) continue;

    const imgEl = card.querySelector("img.s-image");
    products.push({
      title,
      price,
      mrp: price,
      url: asin ? "https://www.amazon.in/dp/" + asin + "?almBrandId=qqfsWw9RkO&fpw=alm" : "",
      image_url: imgEl?.src ?? imgEl?.dataset?.src ?? "",
      inStock: true,
      promo_tag: null,
      bank_offer: null,
      score: _scoreMatch(query, title),
    });
    if (products.length >= 5) break;
  }

  if (!products.length && /captcha|robot check/i.test(html)) {
    throw new Error("CAPTCHA");
  }
  return { products: products.sort((a,b)=>b.score - a.score), vendor_eta, eta_source, is_prime };
}


async function fetchBlinkit(query) {
  const [deviceIdRaw, authKeyRaw, authRaw, locationRaw] = await Promise.all([
    _bgReadLS("https://blinkit.com/*", "deviceId"),
    _bgReadLS("https://blinkit.com/*", "authKey"),
    _bgReadLS("https://blinkit.com/*", "auth"),
    _bgReadLS("https://blinkit.com/*", "location"),
  ]);

  const deviceId = deviceIdRaw ?? "69a4dc20d26945a2";
  const authKey = authKeyRaw ?? "";
  let accessToken = "";
  let lat = "12.967395", lon = "77.7639696";

  try { accessToken = JSON.parse(authRaw ?? "{}").accessToken ?? ""; } catch { }
  try {
    const loc = JSON.parse(locationRaw ?? "{}");
    lat = String(loc?.coords?.lat ?? lat);
    lon = String(loc?.coords?.lon ?? lon);
  } catch { }

  const url =
    "https://blinkit.com/v1/layout/search?q=" +
    encodeURIComponent(query) + "&search_type=type_to_search";
  const text = await _bgFetch(url, {
    method: "POST",
    headers: Object.fromEntries(
      Object.entries({
        "content-type": "application/json",
        "app_client": "consumer_web",
        "web_app_version": "1008010016",
        "platform": "desktop_web",
        "device_id": deviceId,
        "auth_key": authKey,
        "access_token": accessToken,
        "lat": lat,
        "lon": lon,
      }).filter(([, v]) => v !== "")
    ),
    body: JSON.stringify({}),
  });
  const data = JSON.parse(text);
  const snippets = data?.response?.snippets ?? data?.snippets ?? [];
  const products = [];

  // ETA: Blinkit returns a delivery_time snippet alongside product snippets
  let vendor_eta = null;
  let eta_source = "est";
  for (const snippet of snippets) {
    const d = snippet?.data ?? {};
    // Look for a delivery-time widget (various layout_type values Blinkit uses)
    const rawEta = d.delivery_time ?? d.eta?.text ?? d.delivery_eta ?? null;
    if (rawEta) {
      vendor_eta = String(rawEta).replace(/\s+/g, " ").trim();
      eta_source = "live";
      break;
    }
  }
  if (!vendor_eta) {
    // Also try top-level response fields
    vendor_eta = data?.response?.delivery_time ?? data?.delivery_time ?? "10–20 mins";
    eta_source = (data?.response?.delivery_time || data?.delivery_time) ? "live" : "est";
  }

  let eta_debug = null;
  ({ vendor_eta, eta_source, eta_debug } = await _preferOpenTabEta(["*://blinkit.com/*", "*://*.blinkit.com/*"], "Blinkit", vendor_eta, eta_source));

  for (const snippet of snippets) {
    const d = snippet?.data ?? {};
    if (d.layout_type !== "grid") continue;

    const name = d.name?.text ?? d.display_name?.text ?? "";
    const variant = d.variant?.text ?? "";
    const title = variant ? name + " " + variant : name;

    const extractPrice = (v) => {
      if (!v) return 0;
      const s = typeof v === "object" ? (v.text ?? v.value ?? "") : String(v);
      return parseFloat(String(s).replace(/[^0-9.]/g, "")) || 0;
    };
    const firstPrice = (...values) => {
      for (const value of values) {
        const parsed = extractPrice(value);
        if (parsed > 0) return parsed;
      }
      return 0;
    };
    const truthySoldOut = (value) => {
      if (typeof value === "boolean") return value;
      if (typeof value === "number") return value !== 0;
      if (value && typeof value === "object") return truthySoldOut(value.value ?? value.text ?? false);
      const text = String(value ?? "").trim().toLowerCase();
      return ["true", "1", "yes", "sold out", "out of stock", "unavailable"].includes(text);
    };
    const price = firstPrice(d.sp, d.offer_price, d.selling_price, d.discounted_price, d.discountedSellingPrice, d.normal_price, d.price, d.mrp);
    const mrp = extractPrice(d.mrp) || price;
    if (!title || !price) continue;

    const pid = d.product_id ?? d.id ?? "";
    const blWebUrl = d.click_action?.web_url
      || (pid ? `https://blinkit.com/prn/product/prid/${pid}/` : "")
      || `https://blinkit.com/s/?q=${encodeURIComponent(title)}`;
    products.push({
      title,
      price,
      mrp: mrp || price,
      url: blWebUrl,
      deeplink: d.click_action?.blinkit_deeplink?.url ?? "",
      image_url: d.image?.url ?? d.media_container?.media?.[0]?.url ?? "",
      inStock: !(truthySoldOut(d.is_sold_out) || truthySoldOut(d.sold_out) || truthySoldOut(d.out_of_stock) || truthySoldOut(d.outOfStock)),
      promo_tag: d.promotion?.description ?? d.discount_text?.text ?? d.badge_text ?? null,
      bank_offer: d.bank_offers?.[0]?.description ?? d.cashback?.text ?? null,
      pack_size_text: variant,
      variant_text: variant,
      score: _scoreMatch(query, title),
    });
    if (products.length >= 5) break;
  }
  return { products: products.sort((a,b)=>b.score - a.score), vendor_eta, eta_source, eta_debug };
}


async function fetchZepto(query) {
  // Keep weight tokens if they are likely specific SKUs (e.g., 25kg, 26kg)
  const zeptoQuery = query
    .replace(/\b([1-9]|10)\s*(?:kg|g|ml|l)\b/gi, "") // remove small weights
    .replace(/\s+/g, " ")
    .trim() || query;

  const browserId =
    (await _bgReadLS("https://www.zepto.com/*", "unique_browser_id")) ??
    "5653894651872359";
  const storeId = "042b55a7-bfcf-46e8-8cc2-56ba2b4dc7cf";

  const url = "https://bff-gateway.zepto.com/user-search-service/api/v3/search";

  const text = await _bgFetch(url, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "accept": "application/json, text/plain, */*",
      "appversion": "14.35.0",
      "platform": "WEB",
      "storeid": storeId,
      "unique-browser-id": browserId,
    },
    body: JSON.stringify({
      query: zeptoQuery,
      pageNumber: 0,
      intentId: "",
      mode: "AUTOSUGGEST",
      userSessionId: "",
    }),
  });
  const data = _safeParseJSON(text, "Zepto", zeptoQuery);
  const products = [];
  const raw = _collectZeptoItems(data);

  for (const item of raw) {
    const pr = item?.productResponse ?? {};
    const prd = pr?.product ?? {};
    const pv = pr?.productVariant ?? {};

    const brand = prd?.brand ?? "";
    const name = prd?.name ?? "";
    const pack = pv?.formattedPacksize ?? "";
    const title = [brand, name, pack].filter(Boolean).join(" ").trim();

    // Try multiple price fields for accuracy
    const price = item?.sellingPrice ?? pr?.sellingPrice ?? pv?.mrp ?? 0;
    const mrp = pv?.mrp ?? price;
    if (!title || !price) continue;

    const pvId = pv?.id ?? "";
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "product";
    const imgPath = pv?.images?.[0]?.path ?? "";
    products.push({
      title,
      price: parseFloat(price) / 100,
      mrp: parseFloat(mrp) / 100,
      url: pvId ? `https://www.zepto.com/pn/${slug}/pvid/${pvId}/` : "",
      image_url: imgPath ? `https://cdn.zeptonow.com/production/${imgPath.replace(/^\/+/, "")}` : "",
      inStock: (pv?.maxAllowedQuantity ?? pv?.quantity ?? 0) > 0,
      promo_tag: pr.promotions?.[0]?.description ?? pr.badges?.[0]?.text ?? pv?.badge ?? null,
      bank_offer: pr.bankOffers?.[0]?.description ?? pr.cashback?.description ?? null,
      pack_size_text: pack,
      formattedPacksize: pack,
      sku_id: pvId,
      score: _scoreMatch(query, title),
    });
    if (products.length >= 10) break;
  }

  const ranked = products
    .filter(p => p.score > 0.05)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);

  const etaRaw = _findEtaText(data);
  let vendor_eta = etaRaw ?? "10-20 mins";
  let eta_source = etaRaw ? "live" : "est";
  let eta_debug = null;
  ({ vendor_eta, eta_source, eta_debug } = await _preferOpenTabEta(["https://www.zepto.com/*", "*://zepto.com/*", "*://*.zepto.com/*"], "Zepto", vendor_eta, eta_source));

  return { products: ranked, vendor_eta, eta_source, eta_debug };
}



async function fetchInstamart(query) {
  const variants = [query];
  const cleaned = _cleanQuery(query);
  if (cleaned && cleaned !== query) variants.push(cleaned);

  const deviceId = await _bgReadLS("*://*.swiggy.com/*", "deviceId") || "";

  // These additional URL params + body fields are what the working popup version uses
  const url = "https://www.swiggy.com/api/instamart/search/v2?offset=0&ageConsent=false&voiceSearchTrackingId=&storeId=&primaryStoreId=&secondaryStoreId=";
  const fetchData = async (q) => {
    const text = await _bgFetch(url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "accept": "application/json, text/plain, */*",
        "x-build-version": "2.338.0",
        ...(deviceId ? { "x-device-id": deviceId } : {}),
      },
      body: JSON.stringify({
        facets: [],
        sortAttribute: "",
        query: q,
        search_results_offset: "0",
        page_type: "INSTAMART_SEARCH_PAGE",
        is_pre_search_tag: false,
      }),
    });
    return _safeParseJSON(text, "Instamart", q);
  };


  const headers = {
    "content-type": "application/json",
    "x-build-version": "2.338.0",
  };
  if (deviceId) {
    headers["x-device-id"] = deviceId;
  }

  let json = null;
  let usedQuery = variants[0];
  for (const variant of variants) {
    try {
      json = await fetchData(variant);
      const widgets = json?.data?.widgets || json?.data?.cards || [];
      usedQuery = variant;
      if (widgets.length) break;
    } catch (e) {
      console.warn(`[Instamart] Fetch failed for ${variant}`, e);
    }
  }

  const products = [];
  const resData = json?.data || {};
  const widgets = resData.widgets || resData.cards || [];

  if (!widgets.length) {
    console.log(`[Instamart] No widgets in response for query: ${query}`);
    const eta = await _preferOpenTabEta(["*://swiggy.com/*", "*://*.swiggy.com/*"], "Instamart", "15–45 mins", "est");
    return { products: [], ...eta, error: "No matching Instamart products" };
  }

  for (const w of widgets) {
    const wInner = w.data || (w.card && w.card.card);
    if (!wInner) continue;

    // Swiggy wraps products in GridWidget -> gridElements -> infoWithStyle -> items
    const items = _asArray(
      Array.isArray(wInner)
        ? wInner
        : (wInner.gridElements?.infoWithStyle?.items || wInner.items || [])
    );

    for (const item of items) {
      const it = item.item || item;
      if (!it.variations || !it.variations[0]) continue;

      // CONFIRMED SCHEMA (from live API dump 2026-04-21):
      //   it.displayName                           = product name (no qty)
      //   it.brand                                 = brand name
      //   it.variations[0].quantityDescription     = "500 g" / "1 ltr x 2" / "5 kg"
      //   it.variations[0].price.offerPrice.units  = selling price (integer rupees)
      //   it.variations[0].price.mrp.units         = MRP
      //   it.variations[0].skuId                   = SKU / product URL slug
      //   it.variations[0].imageIds[0]             = image path
      const v = it.variations[0];

      const name  = it.displayName || "";
      const brand = (it.brand && !name.toLowerCase().startsWith(it.brand.toLowerCase()))
                    ? it.brand : "";
      const qty   = v.quantityDescription || "";

      // Title includes brand + name + size so the backend scorer can match SKU size
      const title = `${brand} ${name} ${qty}`.replace(/\s+/g, " ").trim();
      if (!title) continue;

      const priceInfo = v.price || {};
      const price = parseInt(priceInfo.offerPrice?.units || priceInfo.units || "0");
      const mrp   = parseInt(priceInfo.mrp?.units || "0") || price;
      const pId   = it.productId || v.skuId || "";
      const imgId = v.imageIds?.[0] || "";

      if (price <= 0) continue;

      products.push({
        title,
        price,
        mrp,
        url:        pId   ? `https://www.swiggy.com/instamart/item/${pId}` : "",
        image_url:  imgId ? `https://instamart-media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,h_200,w_200/${imgId}` : "",
        inStock:    it.inStock !== false && it.isAvail !== false,
        promo_tag:  null,
        bank_offer: null,
        pack_size_text: qty,
        quantityDescription: qty,
        score: _scoreMatch(query, title),
      });
      if (products.length >= 10) break; // collect extra for scoring
    }
    if (products.length >= 10) break;
  }

  // Rank by relevance score
  const ranked = products
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);

  console.log(`[Instamart] Extracted ${ranked.length} ranked products for query: ${query} via '${usedQuery}'`);

  let vendor_eta = resData.deliveryTime || "15–45 mins";
  let eta_source = resData.deliveryTime ? "live" : "est";
  let eta_debug = null;
  ({ vendor_eta, eta_source, eta_debug } = await _preferOpenTabEta(["*://swiggy.com/*", "*://*.swiggy.com/*"], "Instamart", vendor_eta, eta_source));

  return {
    products: ranked,
    vendor_eta,
    eta_source,
    eta_debug,
    error: ranked.length ? null : "No matching Instamart products",
  };
}

function _amazonSearchPrice(card) {
  const whole = card.querySelector("span.a-price-whole")?.textContent || "";
  const fraction = card.querySelector("span.a-price-fraction")?.textContent || "";
  const combined = whole ? `${whole}.${fraction || "00"}` : "";
  return _parseMoney(combined || card.querySelector(".a-price .a-offscreen")?.textContent);
}

function _amazonMrp(card, price) {
  const mrpText =
    card.querySelector(".a-price.a-text-price .a-offscreen")?.textContent ||
    card.querySelector("[data-a-strike='true'] .a-offscreen")?.textContent ||
    card.querySelector(".a-text-price")?.textContent;
  return _parseMoney(mrpText) || price;
}

async function fetchAmazonBeauty(query) {
  const url = "https://www.amazon.in/s?k=" + encodeURIComponent(query) + "&i=beauty";
  const html = await _bgFetch(url, {}, 12000);
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const detectedError = _detectMarketplaceError(html, doc, "Amazon.in");
  const cards = Array.from(doc.querySelectorAll('[data-component-type="s-search-result"][data-asin]'));
  if (detectedError && !cards.length) throw detectedError;

  const isPrime = _parseAmazonIsPrime(doc);
  const products = [];
  for (const card of cards) {
    const asin = _normalizeText(card.getAttribute("data-asin"));
    const titleEl =
      card.querySelector('[data-cy="title-recipe"]') ||
      card.querySelector("h2 span") ||
      card.querySelector("h2");
    const title = _normalizeText(titleEl?.textContent);
    if (!title || card.textContent.toLowerCase().includes("sponsored")) continue;
    const price = _amazonSearchPrice(card);
    const productUrl = asin
      ? `https://www.amazon.in/dp/${asin}`
      : _absoluteUrl(card.querySelector("a.a-link-normal.s-no-outline, h2 a")?.getAttribute("href"), "https://www.amazon.in");
    const stockText = card.textContent;
    const product = _normalizeBeautyProduct("Amazon.in", {
      query,
      title,
      price,
      mrp: _amazonMrp(card, price),
      url: productUrl,
      image_url: card.querySelector("img.s-image")?.src || card.querySelector("img.s-image")?.dataset?.src,
      inStock: !/currently unavailable|out of stock|sold out/i.test(stockText),
      asin,
      promo_tag: card.querySelector(".s-coupon-highlight-color, .a-badge-text, .a-color-secondary")?.textContent,
      bank_offer: _firstMatch(stockText, [/(?:bank offer|instant discount|cashback)[^.₹]{0,120}/i]),
      prime: Boolean(card.querySelector(".s-prime, [aria-label*='Prime' i]")) || isPrime,
    });
    if (product) products.push(product);
    if (products.length >= 10) break;
  }
  if (!products.length) {
    if (detectedError) throw detectedError;
    throw _vendorError("NO_RESULTS", "Amazon.in", "Amazon.in returned no parseable products");
  }
  return {
    products: products.sort((a, b) => b.score - a.score).slice(0, 5),
    vendor_eta: null,
    eta_source: "unavailable",
    is_prime: isPrime,
  };
}

function _nykaaProductsFromJson(doc, query) {
  return _nykaaProductsFromRoots(_parseScriptJsonObjects(doc), query);
}

function _nykaaProductsFromText(text, query) {
  const trimmed = String(text || "").trim();
  if (!/^[\[{]/.test(trimmed)) return [];
  try {
    return _nykaaProductsFromRoots([JSON.parse(trimmed)], query);
  } catch {
    return [];
  }
}

function _nykaaCategoryIdFromUrl(url) {
  const match = String(url || "").match(/\/c\/([0-9]+)(?:[/?#]|$)/i);
  return match?.[1] || "";
}

function _nykaaCategoryApiUrl(categoryId, page = 1) {
  if (!categoryId) return "";
  const params = new URLSearchParams({
    category_id: String(categoryId),
    client: "react",
    filter_format: "v2",
    page_no: String(page),
    platform: "website",
    sort: "popularity",
  });
  return `https://www.nykaa.com/app-api/index.php/products/list?${params.toString()}`;
}

const NYKAA_CATEGORY_FALLBACKS = [
  { pattern: /\b(foundations?|concealers?|compact|bb\s*cream|face\s*powder)\b/i, ids: ["228"] },
  { pattern: /\b(lipstick|lip\s*crayon|lip\s*gloss|lip\s*liner|lip\s*colour|lip\s*color)\b/i, ids: ["9586"] },
  { pattern: /\b(kajal|eyeliner|mascara|eyeshadow|brow|eye\s*primer)\b/i, ids: ["316"] },
  { pattern: /\b(sunscreen|spf|pa\+*)\b/i, ids: ["9574"] },
  { pattern: /\b(serum|retinol|niacinamide|salicylic|hyaluronic|vitamin\s*c|acne\s*spot)\b/i, ids: ["8378"] },
  { pattern: /\b(cleanser|face\s*wash|moisturi[sz]er|micellar|toner|night\s*cream)\b/i, ids: ["1782", "8397"] },
  { pattern: /\b(shampoo|conditioner|hair\s*serum|hair\s*mask|dandruff|curly\s*hair|leave[\s-]*in)\b/i, ids: ["316", "4609", "64208", "9598"] },
  { pattern: /\b(body\s*lotion|body\s*wash|deodorant|perfume|fragrance|body\s*mist|hand\s*cream)\b/i, ids: ["54", "970"] },
];

function _nykaaFallbackCategoryIds(query) {
  const ids = [];
  for (const entry of NYKAA_CATEGORY_FALLBACKS) {
    if (entry.pattern.test(query || "")) ids.push(...entry.ids);
  }
  return [...new Set(ids)];
}

async function _nykaaProductsFromCategoryFallback(query, categoryIds) {
  const products = [];
  const seen = new Set();
  for (const categoryId of categoryIds) {
    for (const page of [1, 2]) {
      const apiUrl = _nykaaCategoryApiUrl(categoryId, page);
      if (!apiUrl) continue;
      const apiText = await _bgFetch(apiUrl, {}, 12000);
      for (const product of _nykaaProductsFromText(apiText, query)) {
        const key = product.product_id || product.sku_id || product.product_url || product.title;
        if (seen.has(key)) continue;
        seen.add(key);
        products.push(product);
      }
    }
  }
  return products;
}

function _nykaaProductsFromRoots(roots, query) {
  const products = [];
  const seen = new Set();
  const pushProduct = (node) => {
    const brand = _firstTruthy(node.brand, node.brandName, node.brand_name, node.brand_name_v2?.[0]);
    const name = _firstTruthy(node.title, node.name, node.productName, node.product_name, node.displayName, node.productTitle, node.product_title);
    const productTitle = _firstTruthy(node.product_title, node.productTitle);
    const title = _normalizeText(
      productTitle && brand && !String(name || "").toLowerCase().includes(String(brand).toLowerCase())
        ? [brand, productTitle].filter(Boolean).join(" ")
        : (name || [brand, productTitle].filter(Boolean).join(" "))
    );
    const price = _parseMoney(_firstTruthy(node.price, node.offerPrice, node.offer_price, node.discountedPrice, node.finalPrice, node.final_price, node.sellingPrice, node.selling_price, node.sp));
    const productId = _normalizeText(_firstTruthy(node.productId, node.product_id, node.id, node.parentId, node.parent_id, node.sku, node.skuId, node.sku_id));
    const mediaImage = Array.isArray(node.media)
      ? node.media.find((entry) => entry?.type !== "video" && entry?.url)?.url
      : "";
    if (!title) return;
    const key = productId || `${title}|${price}`;
    if (seen.has(key)) return;
    seen.add(key);
    const product = _normalizeBeautyProduct("Nykaa", {
      query,
      baseUrl: "https://www.nykaa.com",
      title,
      price: _firstTruthy(node.final_price, node.finalPrice, node.discountedPrice, node.offerPrice, node.offer_price, price),
      mrp: _firstTruthy(node.mrp, node.marketPrice, node.markedPrice, node.originalPrice, node.mop, node.price),
      url: _firstTruthy(node.actionUrl, node.action_url, node.productUrl, node.product_url, node.url, node.desktopUrl, node.desktop_url, node.slug ? `/p/${node.slug}` : ""),
      image_url: _firstTruthy(node.imageUrl, node.image_url, node.image, node.primaryImage, mediaImage),
      inStock: _truthyStock(_firstTruthy(node.inStock, node.isInStock, node.is_saleable, node.gludo_stock, node.availability, node.stockStatus, node.quantity), true),
      sku_id: _firstTruthy(node.sku, node.skuId, node.sku_id, node.childId, node.childSkuId, node.child_sku_id),
      product_id: productId,
      promo_tag: _firstTruthy(node.offer, node.offerText, node.offer_message, node.discount, node.discountText, node.tag, node.secondary_tags),
      bank_offer: _firstTruthy(node.bankOffer, node.bank_offer),
      shade: _firstTruthy(node.shade, node.shadeName, node.color),
      shade_family: _firstTruthy(node.shadeFamily, node.colorFamily),
      variant: _firstTruthy(node.variant, node.variantName, node.packSize, node.size, node.option_text),
      skin_type: _firstTruthy(node.skinType, node.skin_type),
      hair_type: _firstTruthy(node.hairType, node.hair_type),
      finish: _firstTruthy(node.finish, node.product_nudges?.attribute_nudges?.finish?.[0]),
      concern: _firstTruthy(node.concern, node.concerns?.[0]),
      form: _firstTruthy(node.form, node.productForm),
      allow_unknown_price: true,
    });
    if (product) products.push(product);
  };
  for (const json of roots) {
    _walkObjects(json, (node) => {
      if (!node || typeof node !== "object" || Array.isArray(node)) return;
      const hasTitle = node.title || node.name || node.productName || node.product_title || node.productTitle;
      const hasPrice = node.price || node.offerPrice || node.discountedPrice || node.finalPrice || node.final_price || node.sellingPrice;
      const hasNykaaMarker = node.productId || node.product_id || node.sku || node.actionUrl || node.product_url || node.shade || node.primaryImage || node.media;
      if (hasTitle && (hasPrice || hasNykaaMarker)) pushProduct(node);
    });
  }
  return products;
}

async function fetchNykaa(query) {
  const q = encodeURIComponent(query);
  const urls = [
    "https://www.nykaa.com/search/result/?q=" + q,
    "https://www.nykaa.com/search/result/?q=" + q + "&root=search&searchType=Manual&sourcepage=home",
  ];
  let lastDetectedError = null;
  const categoryIdsToTry = new Set(_nykaaFallbackCategoryIds(query));
  for (const url of urls) {
    let response = null;
    let html = "";
    try {
      response = await _bgFetchResponse(url, {}, 12000);
      html = response.text || "";
    } catch (err) {
      lastDetectedError = _vendorError(err.errorType || _classifyVendorError(err), "Nykaa", err.message || "Nykaa fetch failed");
      continue;
    }
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");
    const detectedError = _detectMarketplaceError(html, doc, "Nykaa");
    lastDetectedError = detectedError || lastDetectedError;
    let products = _nykaaProductsFromJson(doc, query);

    if (!products.length) {
      const categoryId = _nykaaCategoryIdFromUrl(response?.url);
      if (categoryId) categoryIdsToTry.add(categoryId);
      const apiUrl = _nykaaCategoryApiUrl(categoryId);
      if (apiUrl) {
        try {
          const apiText = await _bgFetch(apiUrl, {}, 12000);
          products = _nykaaProductsFromText(apiText, query);
        } catch (err) {
          lastDetectedError = _vendorError(err.errorType || _classifyVendorError(err), "Nykaa", err.message || "Nykaa category fetch failed");
        }
      }
    }

    if (!products.length) {
      const cards = Array.from(doc.querySelectorAll('[data-testid*="product" i], .productWrapper, [class*="product" i]')).slice(0, 40);
      products = cards.map((card) => _normalizeBeautyProduct("Nykaa", {
        query,
        baseUrl: "https://www.nykaa.com",
        title: card.querySelector('[title], [class*="title" i], [class*="name" i]')?.getAttribute("title") ||
          card.querySelector('[class*="title" i], [class*="name" i]')?.textContent,
        price: card.querySelector('[class*="price" i]')?.textContent,
        mrp: card.querySelector('[class*="mrp" i], [class*="strike" i]')?.textContent,
        url: card.querySelector("a[href]")?.getAttribute("href"),
        image_url: _imageUrlFromElement(card.querySelector("img"), "https://www.nykaa.com"),
        inStock: !/out of stock|notify me/i.test(card.textContent),
        promo_tag: card.querySelector('[class*="offer" i], [class*="discount" i]')?.textContent,
        allow_unknown_price: true,
      })).filter(Boolean);
    }
    if (products.length) {
      return {
        products: products.sort((a, b) => b.score - a.score).slice(0, 5),
        vendor_eta: null,
        eta_source: "unavailable",
      };
    }
  }
  if (categoryIdsToTry.size) {
    try {
      const products = await _nykaaProductsFromCategoryFallback(query, [...categoryIdsToTry]);
      if (products.length) {
        return {
          products: products.sort((a, b) => b.score - a.score).slice(0, 5),
          vendor_eta: null,
          eta_source: "unavailable",
        };
      }
    } catch (err) {
      lastDetectedError = _vendorError(err.errorType || _classifyVendorError(err), "Nykaa", err.message || "Nykaa category fallback failed");
    }
  }
  if (lastDetectedError && lastDetectedError.errorType !== "FETCH_ERROR") throw lastDetectedError;
  if (lastDetectedError?.errorType === "FETCH_ERROR") throw lastDetectedError;
  throw _vendorError("NO_RESULTS", "Nykaa", "Nykaa returned no parseable products");
}

async function fetchFlipkartBeauty(query) {
  const url = "https://www.flipkart.com/search?q=" + encodeURIComponent(query);
  const html = await _bgFetch(url, {}, 12000);
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const detectedError = _detectMarketplaceError(html, doc, "Flipkart");
  const cards = Array.from(doc.querySelectorAll("a[href*='/p/']")).map((link) => {
    let node = link;
    for (let i = 0; i < 4 && node?.parentElement; i += 1) {
      node = node.parentElement;
      if (/₹/.test(node.textContent || "") && node.querySelector("img")) break;
    }
    return { link, card: node };
  });

  const products = [];
  const seen = new Set();
  for (const { link, card } of cards) {
    const text = _normalizeText(card?.textContent || link.textContent || "");
    const title =
      _normalizeText(link.getAttribute("title")) ||
      _normalizeText(card?.querySelector("[title]")?.getAttribute("title")) ||
      _normalizeText(link.textContent).replace(/₹.*$/, "");
    const price = _parseMoney(text.match(/₹\s*[\d,]+/)?.[0]);
    if (!title || (!price && !/out of stock|sold out|currently unavailable/i.test(text))) continue;
    const productUrl = _absoluteUrl(link.getAttribute("href"), "https://www.flipkart.com");
    const productId = _firstMatch(productUrl, [/[?&]pid=([^&]+)/i, /\/p\/itm([^/?]+)/i]);
    const key = productId || productUrl || `${title}|${price}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const prices = text.match(/₹\s*[\d,]+/g) || [];
    const product = _normalizeBeautyProduct("Flipkart", {
      query,
      baseUrl: "https://www.flipkart.com",
      title,
      price,
      mrp: prices.length > 1 ? prices[1] : price,
      url: productUrl,
      image_url: _imageUrlFromElement(card?.querySelector("img"), "https://www.flipkart.com"),
      inStock: !/out of stock|sold out|currently unavailable/i.test(text),
      product_id: productId,
      promo_tag: _firstMatch(text, [/\b(\d+%\s+off)\b/i, /(special price|hot deal)/i]),
      bank_offer: _firstMatch(text, [/(bank offer|cashback|instant discount)[^.₹]{0,120}/i]),
    });
    if (product) products.push(product);
    if (products.length >= 10) break;
  }
  if (!products.length) {
    if (detectedError) throw detectedError;
    throw _vendorError("NO_RESULTS", "Flipkart", "Flipkart returned no parseable beauty products");
  }
  return {
    products: products.sort((a, b) => b.score - a.score).slice(0, 5),
    vendor_eta: null,
    eta_source: "unavailable",
  };
}

// ── Scoring ───────────────────────────────────────────────────────────────────

function _scoreMatch(query, title) {
  if (!query || !title) return 0;
  const q = query.toLowerCase().replace(/[^\w\s]/g, " ").split(/\s+/).filter(t => t.length > 0);
  const t = title.toLowerCase().replace(/[^\w\s]/g, " ").split(/\s+/).filter(tok => tok.length > 0);
  
  let score = 0;
  const tSet = new Set(t);
  
  for (const qTok of q) {
    if (tSet.has(qTok)) {
      score += 1.0;
    } else {
      const qNum = parseInt(qTok);
      if (!isNaN(qNum) && qNum > 0) {
        for (const tTok of t) {
          const tNum = parseInt(tTok);
          if (!isNaN(tNum) && tNum > 0) {
            if (Math.abs(qNum - tNum) <= 1) {
              score += 0.5;
              break;
            }
          }
        }
      }
    }
  }

  const isLargeQuery = q.some(tok => tok === "25" || tok === "26" || tok === "50");
  const isSmallItem = t.some(tok => tok === "1" || tok === "2" || tok === "5");
  if (isLargeQuery && isSmallItem) score -= 0.5;
  
  return score / q.length;
}


// ── Main orchestrator ─────────────────────────────────────────────────────────

// All vendors run in parallel — all fetches go through the background service
// worker which has extension-level host permissions (no CORS restrictions).
// If any vendor starts rate-limiting under load, move it to SEQUENTIAL_VENDORS.
const PARALLEL_VENDORS = [
  { name: "BigBasket", fn: fetchBigBasket },
  { name: "DMart", fn: fetchDMart },
  { name: "Amazon Fresh", fn: fetchAmazonFresh },
  { name: "Amazon Now", fn: fetchAmazonNow },
  { name: "Blinkit", fn: fetchBlinkit },
  { name: "Zepto", fn: fetchZepto },
  { name: "Instamart", fn: fetchInstamart },
];

// Marketplace beauty pages are intentionally low-concurrency: one query at a time
// keeps extension traffic closer to a normal shopper search session.
const SEQUENTIAL_VENDORS = [
  { name: "Nykaa", fn: fetchNykaa },
  { name: "Amazon.in", fn: fetchAmazonBeauty },
  { name: "Flipkart", fn: fetchFlipkartBeauty },
];

const VENDORS = [...PARALLEL_VENDORS, ...SEQUENTIAL_VENDORS];

/**
 * Fetch prices for all queries from all vendors.
 * Parallel-safe vendors run fully concurrently.
 * Returns grounding in the format expected by the backend:
 *   { [query]: { [vendorName]: { products: [...], vendor_eta: string|null, eta_source: "live"|"est" } } }
 *
 * vendor_eta   — delivery time string from the vendor's own API/HTML (or fallback string)
 * eta_source   — "live" if the value came from the vendor API; "est" if the fallback was used
 */
function _emitVendorProgress(requestId, vendor, startedAt, rows) {
  const productCount = rows.reduce((sum, row) => sum + ((row.products || []).length), 0);
  const firstError = rows.find(row => row.error)?.error || null;
  const firstErrorType = rows.find(row => row.errorType)?.errorType || (firstError ? _classifyVendorError(firstError) : null);
  const payload = {
    type: "CARTSAVVY_VENDOR_PROGRESS",
    requestId,
    vendor,
    status: firstError ? "error" : "done",
    productCount,
    elapsedMs: Date.now() - startedAt,
    error: firstError,
    errorType: firstErrorType,
  };
  window.postMessage(payload, "*");
}

function _filterVendors(vendors, vendorFilter) {
  if (!Array.isArray(vendorFilter) || vendorFilter.length === 0) return vendors;
  const allowed = new Set(vendorFilter);
  return vendors.filter((vendor) => allowed.has(vendor.name));
}

async function fetchAllVendors(queries, requestId = "", vendorFilter = null) {
  const parallelVendors = _filterVendors(PARALLEL_VENDORS, vendorFilter);
  const sequentialVendors = _filterVendors(SEQUENTIAL_VENDORS, vendorFilter);
  const activeVendors = [...parallelVendors, ...sequentialVendors];

  // Parallel vendors — all items × all vendors at once
  const parallelTasks = parallelVendors.map(async (v) => {
    const startedAt = Date.now();
    const rows = await Promise.all(queries.map((q) =>
      v.fn(q)
      .then((result) => {
        if (v.name === "Instamart" || v.name.includes("Amazon")) {
          console.log(`[${v.name}] Fetch success for '${q}'`, result);
        }
        return { vendor: v.name, query: q, ...result };
      })
      .catch((err) => {
        console.error(`[${v.name}] Fetch error for '${q}':`, err);
        return { vendor: v.name, query: q, products: [], vendor_eta: null, eta_source: "est", error: err.message, errorType: err.errorType || _classifyVendorError(err) };
      })
    ));
    _emitVendorProgress(requestId, v.name, startedAt, rows);
    return rows;
  }
  );

  // Sequential vendors — one item at a time per vendor
  const sequentialResults = [];
  for (const v of sequentialVendors) {
    const startedAt = Date.now();
    const vendorRows = [];
    for (const q of queries) {
      const result = await v.fn(q)
        .then((r) => ({ vendor: v.name, query: q, ...r }))
        .catch((err) => ({ vendor: v.name, query: q, products: [], vendor_eta: null, eta_source: "est", error: err.message, errorType: err.errorType || _classifyVendorError(err) }));
      sequentialResults.push(result);
      vendorRows.push(result);
    }
    _emitVendorProgress(requestId, v.name, startedAt, vendorRows);
  }

  const results = [...(await Promise.all(parallelTasks)).flat(), ...sequentialResults];

  // Build grounding map: { query: { vendor: { products, vendor_eta, eta_source } } }
  // vendor_eta is the same across all queries for a vendor (it's a vendor capability,
  // not per-item), so we use the last non-null value seen for each vendor.
  const grounding = {};
  for (const q of queries) {
    grounding[q] = {};
    for (const v of activeVendors) {
      grounding[q][v.name] = { products: [], vendor_eta: null, eta_source: "est", eta_debug: null, is_prime: null };
    }
  }
  for (const r of results) {
    grounding[r.query][r.vendor] = {
      products: r.products ?? [],
      vendor_eta: r.vendor_eta ?? null,
      eta_source: r.eta_source ?? "est",
      eta_debug: r.eta_debug ?? null,
      is_prime: r.is_prime ?? null,  // only set by Amazon fetchers
      error: r.error ?? null,
      errorType: r.errorType ?? null,
    };
  }
  return grounding;
}


// ── Page message listener ─────────────────────────────────────────────────────

window.addEventListener("message", async (event) => {
  if (
    event.source !== window ||
    !event.data ||
    event.data.type !== "CARTSAVVY_FETCH_PRICES"
  ) {
    return;
  }

  const { queries, requestId, vendor_filter } = event.data;
  if (!Array.isArray(queries) || !requestId) return;

  try {
    if (!_runtimeAvailable()) {
      throw new Error("Extension runtime unavailable; reload the CartSavvy tab after reloading the extension");
    }
    const grounding = await fetchAllVendors(queries, requestId, vendor_filter);
    window.postMessage(
      { type: "CARTSAVVY_PRICES_RESULT", requestId, grounding },
      "*"
    );
  } catch (err) {
    window.postMessage(
      { type: "CARTSAVVY_PRICES_RESULT", requestId, grounding: null, error: err.message },
      "*"
    );
  }
});
