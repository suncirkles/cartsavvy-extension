/**
 * CartSavvy content script — injected into the CartSavvy frontend page.
 *
 * Protocol (window.postMessage):
 *   Page → extension : { type: "CARTSAVVY_FETCH_PRICES", queries: string[], requestId: string }
 *   Extension → page : { type: "CARTSAVVY_PRICES_RESULT", requestId: string,
 *                         grounding: { [query]: { [vendor]: [{title,price,mrp,url,inStock}] } } | null,
 *                         error?: string }
 *
 * The page detects extension presence via window.__cartsavvyExtension.
 */

// ── Background messaging helper (for privileged APIs) ────────────────────────

async function _bgReadLS(urlPattern, key) {
  return new Promise((resolve) => {
    try {
      // 1. Try to read from an open tab first (freshest data)
      chrome.runtime.sendMessage({ action: "readLS", urlPattern, key }, (resp) => {
        if (chrome.runtime.lastError || !resp?.value) {
          // 2. Fallback to persisted storage from background service worker
          chrome.runtime.sendMessage({ action: "readStorage", key }, (sResp) => {
            if (chrome.runtime.lastError) { resolve(null); return; }
            resolve(sResp?.value ?? null);
          });
          return;
        }
        resolve(resp.value);
      });
    } catch {
      resolve(null);
    }
  });
}

function _safeParseJSON(text, vendor, query) {
  if (!text) {
    throw new Error(`Empty response from ${vendor}`);
  }
  try {
    return JSON.parse(text);
  } catch (e) {
    console.error(`[${vendor}] JSON Parse failed for query: ${query}`);
    console.error(`[${vendor}] Raw response snippet:`, text.slice(0, 200));
    // Propagate more descriptive error for the UI
    if (text.trim().startsWith("<!DOCTYPE html") || text.trim().startsWith("<html")) {
      throw new Error(`Received HTML instead of JSON from ${vendor} (likely session expired or bot block)`);
    }
    throw new Error(`Malformed JSON from ${vendor}: ${e.message}`);
  }
}

/**
 * Make a request via the background service worker.
 * Background fetches have extension-level host permissions and bypass page CORS.
 * Returns response text, or throws on network error / non-OK status.
 */
async function _bgFetch(url, options = {}, timeoutMs = 10000) {
  const bgPromise = new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage({
        action: "fetch",
        url,
        method: options.method ?? "GET",
        headers: options.headers ?? {},
        body: options.body ?? null,
      }, (resp) => {
        if (chrome.runtime.lastError) { reject(new Error(chrome.runtime.lastError.message)); return; }
        if (resp?.error) { reject(new Error(resp.error)); return; }
        if (!resp?.ok) { reject(new Error("HTTP " + resp?.status)); return; }
        resolve(resp.text);
      });
    } catch (e) {
      reject(e);
    }
  });
  const timeoutPromise = new Promise((_, reject) =>
    setTimeout(() => reject(new Error("bgFetch timeout")), timeoutMs)
  );
  return Promise.race([bgPromise, timeoutPromise]);
}


// ── Vendor fetchers ───────────────────────────────────────────────────────────

async function fetchBigBasket(query) {
  const url =
    "https://www.bigbasket.com/listing-svc/v2/products?" +
    "type=ps&slug=" + encodeURIComponent(query) + "&page=1&bucket_id=52";
  const text = await _bgFetch(url);
  const data = JSON.parse(text);
  const raw = data?.tabs?.[0]?.product_info?.products ?? [];

  // ETA: BigBasket now has q-commerce. The API returns delivery_time or slot_type
  // at the tab or product_info level; check several known field locations.
  const tab0 = data?.tabs?.[0] ?? {};
  const etaRaw =
    tab0.delivery_time ??
    tab0.slot_type ??
    data?.delivery_time ??
    tab0.product_info?.delivery_time ??
    null;
  const vendor_eta = etaRaw ? String(etaRaw) : "Express";
  const eta_source = etaRaw ? "live" : "est";

  const products = raw.slice(0, 5).map((p) => ({
    title: p.desc ?? "",
    price: parseFloat(p.pricing?.discount?.prim_price?.sp ?? 0),
    mrp: parseFloat(p.pricing?.discount?.mrp ?? 0),
    url: "https://www.bigbasket.com" + (p.absolute_url ?? ""),
    image_url: p.images?.m ?? p.images?.s ?? "",
    inStock: p.availability?.button === "Add",
    promo_tag: p.badges?.[0]?.text ?? p.ribbon_text ?? null,
    bank_offer: p.offers?.[0]?.description ?? p.bank_offers?.[0]?.text ?? null,
  })).filter((p) => p.price > 0);

  return { products, vendor_eta, eta_source };
}


/**
 * Parse a delivery ETA string from an Amazon search results page DOM.
 * Returns the ETA string if found (e.g. "Delivery in 2 hours", "Get it by Today"),
 * or null if the pincode is not set / ETA not present.
 * Uses only the already-fetched HTML — no extra network request.
 */
function _parseAmazonIsPrime(doc) {
  // Check inline data first — fastest and most reliable
  for (const script of doc.querySelectorAll("script")) {
    const t = script.textContent;
    if (/"isPrimeMember"\s*:\s*true/.test(t) || /isPrimeMember=true/.test(t)) return true;
    if (/"isPrimeMember"\s*:\s*false/.test(t) || /isPrimeMember=false/.test(t)) return false;
  }
  // Fallback: Prime nav button or badge present in header
  if (doc.querySelector("#nav-prime-btn, .nav-prime, .huc-amazon-prime-text")) return true;
  // Cannot determine — return null so the backend doesn't assume non-prime
  return null;
}

function _parseAmazonEta(doc) {
  // Try 1: success-colored delivery text near the top of the page
  for (const el of doc.querySelectorAll(".a-color-success, .a-color-base")) {
    const t = el.textContent.trim();
    if (/\b(delivery|get it|arrives?|dispatch)\b/i.test(t) &&
      /\b(min|hour|today|tomorrow|\d+\s*hr)/i.test(t)) {
      return t.replace(/\s+/g, " ").slice(0, 60);
    }
  }
  // Try 2: any text node matching a delivery-time pattern
  const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
  const pat = /delivery in \d+[\s\w]+|get it by .{3,40}|arrives? .{3,40}/i;
  let node;
  while ((node = walker.nextNode())) {
    const t = node.textContent.trim();
    const m = t.match(pat);
    if (m) return m[0].replace(/\s+/g, " ").slice(0, 60);
  }
  return null;
}

async function fetchAmazonFresh(query) {
  const url = "https://www.amazon.in/s?k=" + encodeURIComponent(query) + "&i=nowstore";
  const html = await _bgFetch(url);

  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const cards = doc.querySelectorAll('[data-component-type="s-search-result"]');

  // ETA + Prime: parse from already-fetched HTML (pincode must be set in user's session)
  const etaRaw = _parseAmazonEta(doc);
  const vendor_eta = etaRaw ?? "2–4 hrs";
  const eta_source = etaRaw ? "live" : "est";
  const is_prime = _parseAmazonIsPrime(doc);

  const products = [];
  for (const card of cards) {
    if (card.textContent.toLowerCase().includes("sponsored")) continue;
    const asin = card.dataset.asin ?? "";

    const titleEl =
      card.querySelector('[data-cy="title-recipe"]') ?? card.querySelector("h2");
    const title = titleEl ? titleEl.textContent.replace(/\s+/g, " ").trim() : "";
    if (!title || /combo|bundle/i.test(title)) continue;
    if (card.textContent.toLowerCase().includes("currently unavailable")) continue;

    const priceEl = card.querySelector("span.a-price-whole");
    if (!priceEl) continue;
    const price = parseFloat(priceEl.textContent.replace(/[^\d.]/g, ""));
    if (!price) continue;

    const imgEl = card.querySelector("img.s-image");
    products.push({
      title,
      price,
      mrp: price,
      url: asin ? "https://www.amazon.in/dp/" + asin + "?almBrandId=ctnow&fpw=alm" : "",
      image_url: imgEl?.src ?? imgEl?.dataset?.src ?? "",
      inStock: true,
      promo_tag: null,   // Amazon search page has no promo badges
      bank_offer: null,   // Amazon bank offers shown on product page, not in search
    });
    if (products.length >= 5) break;
  }

  if (!products.length && /captcha|robot check/i.test(html)) {
    throw new Error("CAPTCHA");
  }
  return { products, vendor_eta, eta_source, is_prime };
}


async function fetchAmazonNow(query) {
  const url = "https://www.amazon.in/s?k=" + encodeURIComponent(query) + "&i=amazontez";
  const html = await _bgFetch(url);

  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const cards = doc.querySelectorAll('[data-component-type="s-search-result"]');

  // ETA + Prime: parse from already-fetched HTML (pincode must be set in user's session)
  const etaRaw = _parseAmazonEta(doc);
  const vendor_eta = etaRaw ?? "2–4 hrs";
  const eta_source = etaRaw ? "live" : "est";
  const is_prime = _parseAmazonIsPrime(doc);

  const products = [];
  for (const card of cards) {
    if (card.textContent.toLowerCase().includes("sponsored")) continue;
    const asin = card.dataset.asin ?? "";

    const titleEl =
      card.querySelector('[data-cy="title-recipe"]') ?? card.querySelector("h2");
    const title = titleEl ? titleEl.textContent.replace(/\s+/g, " ").trim() : "";
    if (!title || /combo|bundle/i.test(title)) continue;
    if (card.textContent.toLowerCase().includes("currently unavailable")) continue;

    const priceEl = card.querySelector("span.a-price-whole");
    if (!priceEl) continue;
    const price = parseFloat(priceEl.textContent.replace(/[^\d.]/g, ""));
    if (!price) continue;

    const imgEl = card.querySelector("img.s-image");
    products.push({
      title,
      price,
      mrp: price,
      url: asin ? "https://www.amazon.in/dp/" + asin + "?almBrandId=qqfsWw9RkO&fpw=alm" : "",
      image_url: imgEl?.src ?? imgEl?.dataset?.src ?? "",
      inStock: true,
      promo_tag: null,
      bank_offer: null,
    });
    if (products.length >= 5) break;
  }

  if (!products.length && /captcha|robot check/i.test(html)) {
    throw new Error("CAPTCHA");
  }
  return { products, vendor_eta, eta_source, is_prime };
}


async function fetchBlinkit(query) {
  const [deviceIdRaw, authKeyRaw, authRaw, locationRaw] = await Promise.all([
    _bgReadLS("https://blinkit.com/*", "deviceId"),
    _bgReadLS("https://blinkit.com/*", "authKey"),
    _bgReadLS("https://blinkit.com/*", "auth"),
    _bgReadLS("https://blinkit.com/*", "location"),
  ]);

  const deviceId = deviceIdRaw ?? "69a4dc20d26945a2";
  const authKey = authKeyRaw ?? "";
  let accessToken = "";
  let lat = "12.967395", lon = "77.7639696";

  try { accessToken = JSON.parse(authRaw ?? "{}").accessToken ?? ""; } catch { }
  try {
    const loc = JSON.parse(locationRaw ?? "{}");
    lat = String(loc?.coords?.lat ?? lat);
    lon = String(loc?.coords?.lon ?? lon);
  } catch { }

  const url =
    "https://blinkit.com/v1/layout/search?q=" +
    encodeURIComponent(query) + "&search_type=type_to_search";
  const text = await _bgFetch(url, {
    method: "POST",
    headers: Object.fromEntries(
      Object.entries({
        "content-type": "application/json",
        "app_client": "consumer_web",
        "web_app_version": "1008010016",
        "platform": "desktop_web",
        "device_id": deviceId,
        "auth_key": authKey,
        "access_token": accessToken,
        "lat": lat,
        "lon": lon,
      }).filter(([, v]) => v !== "")
    ),
    body: JSON.stringify({}),
  });
  const data = JSON.parse(text);
  const snippets = data?.response?.snippets ?? data?.snippets ?? [];
  const products = [];

  // ETA: Blinkit returns a delivery_time snippet alongside product snippets
  let vendor_eta = null;
  let eta_source = "est";
  for (const snippet of snippets) {
    const d = snippet?.data ?? {};
    // Look for a delivery-time widget (various layout_type values Blinkit uses)
    const rawEta = d.delivery_time ?? d.eta?.text ?? d.delivery_eta ?? null;
    if (rawEta) {
      vendor_eta = String(rawEta).replace(/\s+/g, " ").trim();
      eta_source = "live";
      break;
    }
  }
  if (!vendor_eta) {
    // Also try top-level response fields
    vendor_eta = data?.response?.delivery_time ?? data?.delivery_time ?? "10–20 mins";
    eta_source = (data?.response?.delivery_time || data?.delivery_time) ? "live" : "est";
  }

  for (const snippet of snippets) {
    const d = snippet?.data ?? {};
    if (d.layout_type !== "grid") continue;

    const name = d.name?.text ?? d.display_name?.text ?? "";
    const variant = d.variant?.text ?? "";
    const title = variant ? name + " " + variant : name;

    const extractPrice = (v) => {
      if (!v) return 0;
      const s = typeof v === "object" ? (v.text ?? v.value ?? "") : String(v);
      return parseFloat(String(s).replace(/[^0-9.]/g, "")) || 0;
    };
    const price = extractPrice(d.normal_price ?? d.sp);
    const mrp = extractPrice(d.mrp) || price;
    if (!title || !price) continue;

    const pid = d.product_id ?? d.id ?? "";
    const blWebUrl = d.click_action?.web_url
      || (pid ? `https://blinkit.com/prn/product/prid/${pid}/` : "")
      || `https://blinkit.com/s/?q=${encodeURIComponent(title)}`;
    products.push({
      title,
      price,
      mrp: mrp || price,
      url: blWebUrl,
      deeplink: d.click_action?.blinkit_deeplink?.url ?? "",
      image_url: d.image?.url ?? d.media_container?.media?.[0]?.url ?? "",
      inStock: !(d.is_sold_out ?? false),
      promo_tag: d.promotion?.description ?? d.discount_text?.text ?? d.badge_text ?? null,
      bank_offer: d.bank_offers?.[0]?.description ?? d.cashback?.text ?? null,
    });
    if (products.length >= 5) break;
  }
  return { products, vendor_eta, eta_source };
}


async function fetchZepto(query) {
  const zeptoQuery = query
    .replace(/\b\d+\s*(?:kg|g|ml|l)\b/gi, "")
    .replace(/\s+/g, " ")
    .trim();

  const browserId =
    (await _bgReadLS("https://www.zepto.com/*", "unique_browser_id")) ??
    "5653894651872359";
  const storeId = "042b55a7-bfcf-46e8-8cc2-56ba2b4dc7cf";

  const text = await _bgFetch(
    "https://bff-gateway.zepto.com/user-search-service/api/v3/search",
    {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "accept": "application/json, text/plain, */*",
        "appversion": "14.35.0",
        "storeid": storeId,
        "unique-browser-id": browserId,
      },
      body: JSON.stringify({
        query: zeptoQuery,
        pageNumber: 0,
        intentId: "",
        mode: "AUTOSUGGEST",
        userSessionId: "",
      }),
    }
  );
  const data = JSON.parse(text);
  const products = [];
  const layout = data?.layout ?? [];

  // ETA: Zepto returns deliveryTime at the widget data level or top-level
  let vendor_eta = null;
  let eta_source = "est";
  for (const widget of layout) {
    const wd = widget?.data ?? {};
    const rawEta =
      wd?.deliveryTime ??
      wd?.resolver?.data?.deliveryTime ??
      wd?.slotInfo?.displayText ??
      null;
    if (rawEta) {
      vendor_eta = String(rawEta).replace(/\s+/g, " ").trim();
      eta_source = "live";
      break;
    }
  }
  if (!vendor_eta) {
    vendor_eta = data?.deliveryTime ?? "10–20 mins";
    eta_source = data?.deliveryTime ? "live" : "est";
  }

  for (const widget of layout) {
    const items =
      widget?.data?.resolver?.data?.items ?? widget?.data?.items ?? [];
    for (const item of items) {
      const pr = item?.productResponse ?? {};
      const prd = pr?.product ?? {};
      const pv = pr?.productVariant ?? {};

      const brand = prd?.brand ?? "";
      const name = prd?.name ?? "";
      const pack = pv?.formattedPacksize ?? "";
      const title = [brand, name, pack].filter(Boolean).join(" ").trim();

      const price = pr?.superSaverSellingPrice ?? pv?.mrp ?? 0;
      const mrp = pv?.mrp ?? price;
      if (!title || !price) continue;

      products.push({
        title,
        price: parseFloat(price) / 100,
        mrp: parseFloat(mrp) / 100,
        url: "",
        image_url: pv?.images?.[0]?.path ?? "",
        inStock: (pv?.maxAllowedQuantity ?? pv?.quantity ?? 0) > 0,
        promo_tag: pr.promotions?.[0]?.description ?? pr.badges?.[0]?.text ?? pv?.badge ?? null,
        bank_offer: pr.bankOffers?.[0]?.description ?? pr.cashback?.description ?? null,
      });
      if (products.length >= 5) break;
    }
    if (products.length >= 5) break;
  }
  return { products, vendor_eta, eta_source };
}


async function fetchInstamart(query) {
  // Strip quantity tokens — Instamart search can struggle with them
  const instamartQuery = query
    .replace(/\b\d+\s*(?:kg|g|gm|ml|l)\b/gi, "")
    .replace(/[/-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  // Deduplicate tokens (fixes "Tata Sampann Tata Sampann" hallucination issues)
  const tokens = instamartQuery.split(/\s+/);
  const cleanQuery = [...new Set(tokens)].join(" ");

  const deviceId = await _bgReadLS("*://*.swiggy.com/*", "deviceId") || "";

  // These additional URL params + body fields are what the working popup version uses
  const url = "https://www.swiggy.com/api/instamart/search/v2?offset=0&ageConsent=false&voiceSearchTrackingId=&storeId=&primaryStoreId=&secondaryStoreId=";
  const body = JSON.stringify({
    facets: [],
    sortAttribute: "",
    query: cleanQuery || query,
    search_results_offset: "0",
    page_type: "INSTAMART_SEARCH_PAGE",
    is_pre_search_tag: false
  });

  const headers = {
    "content-type": "application/json",
    "x-build-version": "2.338.0",
  };
  if (deviceId) {
    headers["x-device-id"] = deviceId;
  }

  const text = await _bgFetch(url, { method: "POST", headers, body });
  console.log(`[Instamart] Fetch raw response text length: ${text.length}`);
  const json = _safeParseJSON(text, "Instamart", cleanQuery);

  const products = [];
  const resData = json.data || {};
  const widgets = resData.widgets || resData.cards || [];

  if (!widgets.length) {
    console.log(`[Instamart] No widgets in response for query: ${query}`);
    return { products: [], vendor_eta: "15–45 mins", eta_source: "est" };
  }

  for (const w of widgets) {
    const wInner = w.data || (w.card && w.card.card);
    if (!wInner) continue;

    // Swiggy wraps products in GridWidget -> gridElements -> infoWithStyle -> items
    const items = Array.isArray(wInner)
      ? wInner
      : (wInner.gridElements?.infoWithStyle?.items || wInner.items || []);

    for (const item of items) {
      const it = item.item || item;
      if (!it.variations || !it.variations[0]) continue;

      // CONFIRMED SCHEMA (from live API dump 2026-04-21):
      //   it.displayName                           = product name (no qty)
      //   it.brand                                 = brand name
      //   it.variations[0].quantityDescription     = "500 g" / "1 ltr x 2" / "5 kg"
      //   it.variations[0].price.offerPrice.units  = selling price (integer rupees)
      //   it.variations[0].price.mrp.units         = MRP
      //   it.variations[0].skuId                   = SKU / product URL slug
      //   it.variations[0].imageIds[0]             = image path
      const v = it.variations[0];

      const name  = it.displayName || "";
      const brand = (it.brand && !name.toLowerCase().startsWith(it.brand.toLowerCase()))
                    ? it.brand : "";
      const qty   = v.quantityDescription || "";

      // Title includes brand + name + size so the backend scorer can match SKU size
      const title = `${brand} ${name} ${qty}`.replace(/\s+/g, " ").trim();
      if (!title) continue;

      const priceInfo = v.price || {};
      const price = parseInt(priceInfo.offerPrice?.units || priceInfo.units || "0");
      const mrp   = parseInt(priceInfo.mrp?.units || "0") || price;
      const pId   = it.productId || v.skuId || "";
      const imgId = v.imageIds?.[0] || "";

      if (price <= 0) continue;

      products.push({
        title,
        price,
        mrp,
        url:        pId   ? `https://www.swiggy.com/instamart/item/${pId}` : "",
        image_url:  imgId ? `https://instamart-media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,h_200,w_200/${imgId}` : "",
        inStock:    it.inStock !== false && it.isAvail !== false,
        promo_tag:  null,
        bank_offer: null,
      });
      if (products.length >= 10) break; // collect extra for scoring
    }
    if (products.length >= 10) break;
  }

  // Rank by relevance score
  const ranked = products
    .map(p => ({ ...p, score: _scoreMatch(query, p.title) }))
    .filter(p => p.score > 0.05)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);

  console.log(`[Instamart] Extracted ${ranked.length} ranked products for query: ${query}`);

  const vendor_eta = resData.deliveryTime || "15–45 mins";
  const eta_source = resData.deliveryTime ? "live" : "est";

  return { products: ranked, vendor_eta, eta_source };
}

// ── Scoring ───────────────────────────────────────────────────────────────────

function _tokenize(text) {
  const stop = new Set(["the", "a", "an", "and", "of", "for", "with", "in", "on", "by"]);
  return new Set(
    text.toLowerCase()
      .replace(/(\d+)\s*(kg|gm|g|ml|l)\b/gi, "$1 $2")
      .replace(/[^\w\s]/g, " ")
      .split(/\s+/)
      .filter((t) => t.length > 1 && !stop.has(t))
  );
}

function _scoreMatch(query, title) {
  const qt = _tokenize(query), tt = _tokenize(title);
  if (!qt.size) return 0;
  let matches = 0;
  for (const t of qt) if (tt.has(t)) matches++;
  return matches / qt.size;
}


// ── Main orchestrator ─────────────────────────────────────────────────────────

// All vendors run in parallel — all fetches go through the background service
// worker which has extension-level host permissions (no CORS restrictions).
// If any vendor starts rate-limiting under load, move it to SEQUENTIAL_VENDORS.
const PARALLEL_VENDORS = [
  { name: "BigBasket", fn: fetchBigBasket },
  { name: "Amazon Fresh", fn: fetchAmazonFresh },
  { name: "Amazon Now", fn: fetchAmazonNow },
  { name: "Blinkit", fn: fetchBlinkit },
  { name: "Zepto", fn: fetchZepto },
  { name: "Instamart", fn: fetchInstamart },
];

// Reserved for vendors that rate-limit by hanging connections under parallel load.
const SEQUENTIAL_VENDORS = [];

const VENDORS = [...PARALLEL_VENDORS, ...SEQUENTIAL_VENDORS];

/**
 * Fetch prices for all queries from all vendors.
 * Parallel-safe vendors run fully concurrently.
 * Returns grounding in the format expected by the backend:
 *   { [query]: { [vendorName]: { products: [...], vendor_eta: string|null, eta_source: "live"|"est" } } }
 *
 * vendor_eta   — delivery time string from the vendor's own API/HTML (or fallback string)
 * eta_source   — "live" if the value came from the vendor API; "est" if the fallback was used
 */
async function fetchAllVendors(queries) {
  // Parallel vendors — all items × all vendors at once
  const parallelTasks = PARALLEL_VENDORS.flatMap((v) =>
    queries.map((q) =>
      v.fn(q)
        .then((result) => {
          if (v.name === "Instamart" || v.name.includes("Amazon")) {
            console.log(`[${v.name}] Fetch success for '${q}'`, result);
          }
          return { vendor: v.name, query: q, ...result };
        })
        .catch((err) => {
          console.error(`[${v.name}] Fetch error for '${q}':`, err);
          return { vendor: v.name, query: q, products: [], vendor_eta: null, eta_source: "est", error: err.message };
        })
    )
  );

  // Sequential vendors — one item at a time per vendor
  const sequentialResults = [];
  for (const v of SEQUENTIAL_VENDORS) {
    for (const q of queries) {
      const result = await v.fn(q)
        .then((r) => ({ vendor: v.name, query: q, ...r }))
        .catch((err) => ({ vendor: v.name, query: q, products: [], vendor_eta: null, eta_source: "est", error: err.message }));
      sequentialResults.push(result);
    }
  }

  const results = [...(await Promise.all(parallelTasks)), ...sequentialResults];

  // Build grounding map: { query: { vendor: { products, vendor_eta, eta_source } } }
  // vendor_eta is the same across all queries for a vendor (it's a vendor capability,
  // not per-item), so we use the last non-null value seen for each vendor.
  const grounding = {};
  for (const q of queries) {
    grounding[q] = {};
    for (const v of VENDORS) {
      grounding[q][v.name] = { products: [], vendor_eta: null, eta_source: "est", is_prime: null };
    }
  }
  for (const r of results) {
    grounding[r.query][r.vendor] = {
      products: r.products ?? [],
      vendor_eta: r.vendor_eta ?? null,
      eta_source: r.eta_source ?? "est",
      is_prime: r.is_prime ?? null,  // only set by Amazon fetchers
      error: r.error ?? null,
    };
  }
  return grounding;
}


// ── Page message listener ─────────────────────────────────────────────────────

window.addEventListener("message", async (event) => {
  if (
    event.source !== window ||
    !event.data ||
    event.data.type !== "CARTSAVVY_FETCH_PRICES"
  ) {
    return;
  }

  const { queries, requestId } = event.data;
  if (!Array.isArray(queries) || !requestId) return;

  try {
    const grounding = await fetchAllVendors(queries);
    window.postMessage(
      { type: "CARTSAVVY_PRICES_RESULT", requestId, grounding },
      "*"
    );
  } catch (err) {
    window.postMessage(
      { type: "CARTSAVVY_PRICES_RESULT", requestId, grounding: null, error: err.message },
      "*"
    );
  }
});
