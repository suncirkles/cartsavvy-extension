
// ── Helpers ──────────────────────────────────────────────────────────────────

async function safeJson(resp) {
  if (resp.status === 204) {
    console.warn("Response status 204 (No Content)");
    return null;
  }
  const text = await resp.text();
  if (!text || !text.trim()) {
    console.warn("Response body is empty (status " + resp.status + ")");
    return null;
  }
  try {
    return JSON.parse(text);
  } catch (e) {
    console.error("JSON parse error:", e, "Text snippet:", text.slice(0, 500));
    return null;
  }
}

function cleanQuery(q) {
  return q
    .replace(/\b(\d+)\s*(?:kg|g|gm|ml|l|ltr|litre|litres)\b/gi, "") // sizes
    .replace(/\bpack\s+of\s+\d+\b/gi, "")                          // pack of X
    .replace(/\b(?:x|qty|quantity)\s*\d+\b/gi, "")                // x 2, qty 2
    .replace(/\s+/g, " ")
    .trim();
}

// ── Session helpers ───────────────────────────────────────────────────────────

// Read a localStorage key from a tab matching urlPattern.
// Returns null if no matching tab is open or key is absent.
async function readTabLocalStorage(urlPattern, key) {
  try {
    const tabs = await chrome.tabs.query({ url: urlPattern });
    if (!tabs.length) {
      // Fallback: try reading from extension storage if we cached it previously
      const cached = await chrome.storage.local.get(key);
      return cached[key] ?? null;
    }
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: (k) => localStorage.getItem(k),
      args: [key],
    });
    const val = results?.[0]?.result ?? null;
    if (val) {
      // Cache it for future use when tab is closed
      await chrome.storage.local.set({ [key]: val });
    }
    return val;
  } catch {
    return null;
  }
}

// ── Vendor fetchers ───────────────────────────────────────────────────────────

async function fetchBigBasket(query) {
  const fetchWithQuery = async (q) => {
    const url = `https://www.bigbasket.com/listing-svc/v2/products?` +
      `type=ps&slug=${encodeURIComponent(q)}&page=1&bucket_id=52`;
    const resp = await fetch(url, { credentials: "include" });
    if (!resp.ok) throw new Error(`BB ${resp.status}`);
    return await safeJson(resp);
  };

  let data = await fetchWithQuery(query);
  
  // Retry with cleaned query if no products found
  const getProducts = (d) => d?.tabs?.[0]?.product_info?.products ?? [];
  if (!getProducts(data).length) {
    const cleaned = cleanQuery(query);
    if (cleaned && cleaned !== query) {
      data = await fetchWithQuery(cleaned);
    }
  }

  const raw = getProducts(data);
  if (!raw.length) return [];
  return raw.slice(0, 5).map(p => ({
    title:   p.desc ?? "",
    price:   parseFloat(p.pricing?.discount?.prim_price?.sp ?? 0),
    mrp:     parseFloat(p.pricing?.discount?.mrp ?? 0),
    url:     "https://www.bigbasket.com" + (p.absolute_url ?? ""),
    inStock: p.availability?.button === "Add",
    pack_size_text: p.w ?? "",
    w: p.w ?? "",
    unit: p.unit ?? p.pricing?.discount?.prim_price?.base_unit ?? "",
  })).filter(p => p.price > 0);
}


async function fetchAmazonFresh(query) {
  const url = `https://www.amazon.in/s?k=${encodeURIComponent(query)}&i=nowstore`;
  const resp = await fetch(url, { credentials: "include" });
  if (!resp.ok) throw new Error(`AMZ ${resp.status}`);
  const html = await resp.text();

  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const cards = doc.querySelectorAll('[data-component-type="s-search-result"]');

  const products = [];
  for (const card of cards) {
    if (card.textContent.toLowerCase().includes("sponsored")) continue;
    const asin = card.dataset.asin ?? "";

    // Full title in data-cy=title-recipe; join whitespace-normalised
    const titleEl = card.querySelector('[data-cy="title-recipe"]') ?? card.querySelector("h2");
    const title = titleEl ? titleEl.textContent.replace(/\s+/g, " ").trim() : "";
    if (!title || /combo|bundle/i.test(title)) continue;
    if (card.textContent.toLowerCase().includes("currently unavailable")) continue;

    const priceEl = card.querySelector("span.a-price-whole");
    if (!priceEl) continue;
    const price = parseFloat(priceEl.textContent.replace(/[^\d.]/g, ""));
    if (!price) continue;

    const img = card.querySelector("img.s-image");
    products.push({
      title,
      price,
      mrp: price,
      url: asin ? `https://www.amazon.in/dp/${asin}?almBrandId=ctnow&fpw=alm` : "",
      inStock: true,
    });
    if (products.length >= 5) break;
  }

  // Detect CAPTCHA page
  if (!products.length && /captcha|robot check/i.test(html)) {
    throw new Error("CAPTCHA");
  }
  return products;
}


async function fetchAmazonNow(query) {
  const url = `https://www.amazon.in/s?k=${encodeURIComponent(query)}&s=amazontez`;
  const resp = await fetch(url, { credentials: "include" });
  if (!resp.ok) throw new Error(`AMZNOW ${resp.status}`);
  const html = await resp.text();

  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const cards = doc.querySelectorAll('[data-component-type="s-search-result"]');

  const products = [];
  for (const card of cards) {
    if (card.textContent.toLowerCase().includes("sponsored")) continue;
    const asin = card.dataset.asin ?? "";

    const titleEl = card.querySelector('[data-cy="title-recipe"]') ?? card.querySelector("h2");
    const title = titleEl ? titleEl.textContent.replace(/\s+/g, " ").trim() : "";
    if (!title || /combo|bundle/i.test(title)) continue;
    if (card.textContent.toLowerCase().includes("currently unavailable")) continue;

    const priceEl = card.querySelector("span.a-price-whole");
    if (!priceEl) continue;
    const price = parseFloat(priceEl.textContent.replace(/[^\d.]/g, ""));
    if (!price) continue;

    products.push({
      title,
      price,
      mrp: price,
      url: asin ? `https://www.amazon.in/dp/${asin}?almBrandId=qqfsWw9RkO&fpw=alm` : "",
      inStock: true,
    });
    if (products.length >= 5) break;
  }

  if (!products.length && /captcha|robot check/i.test(html)) {
    throw new Error("CAPTCHA");
  }
  return products;
}


async function fetchBlinkit(query) {
  // Read all session values from live Blinkit tab's localStorage
  const [deviceIdRaw, authKeyRaw, authRaw, locationRaw] = await Promise.all([
    readTabLocalStorage("https://blinkit.com/*", "deviceId"),
    readTabLocalStorage("https://blinkit.com/*", "authKey"),
    readTabLocalStorage("https://blinkit.com/*", "auth"),
    readTabLocalStorage("https://blinkit.com/*", "location"),
  ]);

  const deviceId    = deviceIdRaw    ?? "69a4dc20d26945a2";
  const authKey     = authKeyRaw     ?? "";
  let   accessToken = "";
  let   lat = "", lon = "";
  try { accessToken = JSON.parse(authRaw ?? "{}").accessToken ?? ""; } catch {}
  try {
    const loc = JSON.parse(locationRaw ?? "{}");
    lat = String(loc?.coords?.lat ?? "12.967395");
    lon = String(loc?.coords?.lon ?? "77.7639696");
  } catch {
    lat = "12.967395";
    lon = "77.7639696";
  }

  const url = `https://blinkit.com/v1/layout/search?q=${encodeURIComponent(query)}&search_type=type_to_search`;
  const resp = await fetch(url, {
    method: "POST",
    credentials: "include",
    headers: Object.fromEntries(Object.entries({
      "content-type":    "application/json",
      "app_client":      "consumer_web",
      "web_app_version": "1008010016",
      "platform":        "desktop_web",
      "device_id":       deviceId,
      "auth_key":        authKey,
      "access_token":    accessToken,
      "lat":             lat,
      "lon":             lon,
    }).filter(([, v]) => v !== "")),
  });
  if (!resp.ok) {
    const body = await resp.text();
    console.log("BL error body:", body.slice(0, 300));
    throw new Error(`BL ${resp.status}`);
  }
  const data = await safeJson(resp);
  const products = [];
  const snippets = data?.response?.snippets ?? data?.snippets ?? [];

  for (const snippet of snippets) {
    const d = snippet?.data ?? {};
    if (d.layout_type !== "grid") continue;

    const name    = d.name?.text ?? d.display_name?.text ?? "";
    const variant = d.variant?.text ?? "";
    const title   = variant ? `${name} ${variant}` : name;

    // price fields are objects with text like "₹60" — strip currency symbol
    const extractPrice = v => {
      if (!v) return 0;
      const s = typeof v === "object" ? (v.text ?? v.value ?? "") : String(v);
      return parseFloat(String(s).replace(/[^0-9.]/g, "")) || 0;
    };
    const price = extractPrice(d.normal_price ?? d.sp);
    const mrp   = extractPrice(d.mrp) || price;

    if (!title || !price) continue;

    const imageUrl = d.image?.url ?? d.media_container?.media?.[0]?.url ?? "";
    const deeplink = d.click_action?.blinkit_deeplink?.url ?? "";

    products.push({
      title,
      price,
      mrp:     mrp || price,
      url:     deeplink,
      inStock: !(d.is_sold_out ?? false),
      pack_size_text: variant,
      variant_text: variant,
    });
    if (products.length >= 5) break;
  }
  return products;
}


async function fetchZepto(query) {
  // Strip quantity tokens — Zepto returns 0 results for "toor dal 1kg"
  const zeptoQuery = query.replace(/\b\d+\s*(?:kg|g|ml|l)\b/gi, "").replace(/\s+/g, " ").trim();

  // Read session values from live Zepto tab's localStorage
  const browserId = await readTabLocalStorage("https://www.zepto.com/*", "unique_browser_id")
                 ?? "5653894651872359";
  const storeId   = "042b55a7-bfcf-46e8-8cc2-56ba2b4dc7cf";

  const resp = await fetch(
    "https://bff-gateway.zepto.com/user-search-service/api/v3/search",
    {
      method: "POST",
      credentials: "include",
      headers: {
        "content-type":      "application/json",
        "accept":            "application/json, text/plain, */*",
        "appversion":        "14.35.0",
        "storeid":           storeId,
        "unique-browser-id": browserId,
      },
      body: JSON.stringify({
        query: zeptoQuery,
        pageNumber: 0,
        intentId: "",
        mode: "AUTOSUGGEST",
        userSessionId: "",
      }),
    }
  );
  if (!resp.ok) throw new Error(`ZP ${resp.status}`);
  const data = await safeJson(resp);

  // Iterate all layout widgets — try every widget's items regardless of widgetId
  const products = [];
  const layout = data?.layout ?? [];
  for (const widget of layout) {
    const items = widget?.data?.resolver?.data?.items
               ?? widget?.data?.items
               ?? [];
    for (const item of items) {
      const pr  = item?.productResponse ?? {};
      const prd = pr?.product ?? {};
      const pv  = pr?.productVariant ?? {};

      const brand = prd?.brand ?? "";
      const name  = prd?.name  ?? "";
      const pack  = pv?.formattedPacksize ?? "";
      const title = [brand, name, pack].filter(Boolean).join(" ").trim();

      // superSaverSellingPrice is the actual selling price (in paise)
      const price = pr?.superSaverSellingPrice ?? pv?.mrp ?? 0;
      const mrp   = pv?.mrp ?? price;

      if (!title || !price) continue;
      products.push({
        title,
        price:   parseFloat(price) / 100,
        mrp:     parseFloat(mrp) / 100,
        url:     pv?.images?.[0]?.path ?? "",
        inStock: (pv?.maxAllowedQuantity ?? pv?.quantity ?? 0) > 0,
        pack_size_text: pack,
        formattedPacksize: pack,
      });
      if (products.length >= 10) break; // collect extra for scoring
    }
    if (products.length >= 10) break;
  }

  // Rank by relevance score
  const ranked = products
    .map(p => ({ ...p, score: scoreMatch(query, p.title) }))
    .filter(p => p.score > 0.05)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);

  return ranked;
}

async function fetchInstamart(query) {
  const deviceId = await readTabLocalStorage("https://www.swiggy.com/*", "deviceId") || "";
  if (deviceId) {
    chrome.storage.local.set({ "deviceId": deviceId });
  }

  const url = "https://www.swiggy.com/api/instamart/search/v2?offset=0&ageConsent=false&voiceSearchTrackingId=&storeId=&primaryStoreId=&secondaryStoreId=";
  const headers = {
    "content-type": "application/json",
    "x-build-version": "2.338.0"
  };
  if (deviceId) {
    headers["x-device-id"] = deviceId;
  }

  const fetchWithQuery = async (q) => {
    const body = JSON.stringify({
      facets: [],
      sortAttribute: "",
      query: q,
      search_results_offset: "0",
      page_type: "INSTAMART_SEARCH_PAGE",
      is_pre_search_tag: false
    });
    console.log(`[Instamart] Fetching with query: "${q}"`, { url, headers });
    const resp = await fetch(url, { method: "POST", headers, body });
    if (!resp.ok) {
      console.error(`[Instamart] HTTP Error: ${resp.status}`);
      throw new Error(`IM ${resp.status}`);
    }
    return await safeJson(resp);
  };

  let json = await fetchWithQuery(query);
  console.log("[Instamart] Raw API response:", json);
  
  // If no results, retry with cleaned query
  const getProductsLength = (d) => {
    const widgets = d?.data?.widgets || d?.data?.cards || [];
    return widgets.length;
  };

  if (!getProductsLength(json)) {
    const cleaned = cleanQuery(query);
    if (cleaned && cleaned !== query) {
      json = await fetchWithQuery(cleaned);
    }
  }

  if (!json) return [];

  const products = [];
  const resData = json.data || {};
  const widgets = resData.widgets || resData.cards || [];
  if (!widgets.length) return products;

  for (const w of widgets) {
    const wInner = w.data || (w.card && w.card.card);
    if (!wInner) continue;

    // Swiggy wraps products in GridWidget -> gridElements -> infoWithStyle -> items
    const items = Array.isArray(wInner)
      ? wInner
      : (wInner.gridElements?.infoWithStyle?.items || wInner.items || []);

    for (const item of items) {
      const it = item.item || item;
      // Some versions of the API nest the variant, others have it at the top
      const variations = it.variations || (it.product_variants ? [{...it.product_variants[0], price: it.price}] : []);
      if (!variations || !variations[0]) continue;

      const v = variations[0];
      const name  = it.displayName || it.name || "";
      const brand = (it.brand && !name.toLowerCase().startsWith(it.brand.toLowerCase()))
                    ? it.brand : "";
      const qty   = v.quantityDescription || v.formatted_packsize || "";

      const title = `${brand} ${name} ${qty}`.replace(/\s+/g, " ").trim();
      if (!title) continue;

      const priceInfo = v.price || it.price || {};
      const price = parseInt(priceInfo.offerPrice?.units || priceInfo.units || priceInfo.mrp || "0");
      const mrp   = parseInt(priceInfo.mrp?.units || priceInfo.mrp || "0") || price;
      const pId   = it.productId || v.skuId || it.id || "";
      const imgId = (v.imageIds && v.imageIds[0]) || it.cloudinary_id || "";

      if (price <= 0) continue;

      const finalImageUrl = imgId ? (imgId.startsWith('http') ? imgId : `https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,h_300,w_300/${imgId.startsWith('/') ? imgId.slice(1) : imgId}`) : "";

      products.push({
        title,
        price,
        mrp:        mrp,
        url:        pId   ? `https://www.swiggy.com/instamart/item/${pId}` : "",
        image_url:  finalImageUrl,
        inStock:    it.inStock !== false && it.isAvail !== false,
        promo_tag:  null,
        bank_offer: null,
        pack_size_text: qty,
        quantityDescription: qty,
      });
      if (products.length >= 10) break;
    }
    if (products.length >= 10) break;
  }

  // Rank by relevance score
  const ranked = products
    .map(p => ({ ...p, score: scoreMatch(query, p.title) }))
    .filter(p => p.score > 0.05)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);

  return ranked;
}

// ── Scoring ───────────────────────────────────────────────────────────────────

function tokenize(text) {
  const stop = new Set(["the","a","an","and","of","for","with","in","on","by"]);
  // Normalise "500gm" → "500 gm", "1kg" → "1 kg", "litre" → "l" etc
  const normalized = text.toLowerCase()
    .replace(/\b(\d+)\s*(?:kg|g|gm|ml|l|ltr|litre|litres)\b/gi, "$1 $2")
    .replace(/\blitre[s]?\b/gi, "l")
    .replace(/\bgm\b/gi, "g")
    .replace(/[^\w\s]/g, " ");
  return new Set(
    normalized.split(/\s+/).filter(t => t.length > 1 && !stop.has(t))
  );
}

function scoreMatch(query, title) {
  const qt = tokenize(query), tt = tokenize(title);
  if (!qt.size) return 0;
  let matches = 0;
  for (const t of qt) if (tt.has(t)) matches++;
  return matches / qt.size;
}

function bestMatch(query, products, minScore = 0.4) {
  const scored = products
    .map(p => ({ ...p, score: scoreMatch(query, p.title) }))
    .filter(p => p.score >= minScore)
    .sort((a, b) => b.score - a.price / 10000 - a.score);
  return scored[0] ?? null;
}


// ── Main ──────────────────────────────────────────────────────────────────────

const VENDORS = [
  { name: "BigBasket",    fn: fetchBigBasket   },
  { name: "Amazon Fresh", fn: fetchAmazonFresh  },
  { name: "Amazon Now",   fn: fetchAmazonNow    },
  { name: "Blinkit",      fn: fetchBlinkit      },
  { name: "Zepto",        fn: fetchZepto        },
  { name: "Instamart",    fn: fetchInstamart    },
];

document.getElementById("fetch-btn").addEventListener("click", async () => {
  try {
  const textarea = document.getElementById("items");
  const queries = textarea.value.split("\n").map(s => s.trim()).filter(Boolean);
  if (!queries.length) return;

  const statusEl  = document.getElementById("status");
  const resultsEl = document.getElementById("results");
  resultsEl.innerHTML = "";
  statusEl.textContent = "Fetching...";

  const t0 = Date.now();

  // Fire all (vendor × item) fetches in parallel
  const allTasks = VENDORS.flatMap(v =>
    queries.map(q => v.fn(q).then(products => ({ vendor: v.name, query: q, products }))
                         .catch(err   => ({ vendor: v.name, query: q, error: err.message })))
  );
  const allResults = await Promise.all(allTasks);
  const elapsed = Date.now() - t0;

  // Group by query
  const byQuery = {};
  for (const q of queries) byQuery[q] = {};
  for (const r of allResults) {
    byQuery[r.query][r.vendor] = r;
  }

  // Render
  let html = "";
  for (const query of queries) {
    html += `<div class="item-block"><div class="item-name">${query}</div>`;
    for (const v of VENDORS) {
      const r = byQuery[query][v.name];
      if (r.error) {
        html += `<div class="vendor-row">
          <span class="vendor">${v.name}</span>
          <span class="error">${r.error}</span>
        </div>`;
      } else {
        const best = bestMatch(query, r.products);
        if (best) {
          const mrpStr = best.mrp > best.price ? ` <s style="color:#999">Rs${best.mrp}</s>` : "";
          html += `<div class="vendor-row">
            <span class="vendor">${v.name}</span>
            <span class="price">Rs ${best.price}${mrpStr}</span>
            <span class="title">${best.title}</span>
          </div>`;
        } else {
          html += `<div class="vendor-row">
            <span class="vendor">${v.name}</span>
            <span style="color:#999">no match (${r.products.length} results)</span>
          </div>`;
        }
      }
    }
    html += `</div>`;
  }

  resultsEl.innerHTML = html;
  statusEl.textContent = `Done in ${elapsed}ms`;

  // Show Save button now that we have data
  const saveBtn = document.getElementById("save-btn");
  saveBtn.style.display = "inline-block";
  saveBtn._byQuery = byQuery;   // stash for the save handler

  } catch (err) {
    console.error("Top-level error:", err);
    document.getElementById("status").textContent = "Error: " + err.message;
  }
});


// ── Save for testing ──────────────────────────────────────────────────────────

document.getElementById("save-btn").addEventListener("click", async () => {
  const saveBtn    = document.getElementById("save-btn");
  const saveStatus = document.getElementById("save-status");
  const byQuery    = saveBtn._byQuery;
  if (!byQuery) return;

  // Convert to extension wire format expected by the backend
  const grounding = {};
  for (const [query, vendors] of Object.entries(byQuery)) {
    grounding[query] = {};
    for (const [vendor, r] of Object.entries(vendors)) {
      grounding[query][vendor] = {
        products: (r.products || []).map(p => ({
          title:      p.title      ?? "",
          price:      p.price      ?? 0,
          mrp:        p.mrp        ?? p.price ?? 0,
          url:        p.url        ?? "",
          image_url:  p.image_url  ?? "",
          inStock:    p.inStock    !== false,
          promo_tag:  p.promo_tag  ?? null,
          bank_offer: p.bank_offer ?? null,
        })),
      };
    }
  }

  saveStatus.textContent = "Saving...";
  saveStatus.style.color = "#555";

  try {
    const resp = await fetch("http://localhost:8001/debug/save-grounding", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify(grounding),
    });
    if (resp.ok) {
      const { path, products } = await resp.json();
      saveStatus.style.color = "#1a7f37";
      saveStatus.textContent = `Saved ${products} products to ${path}`;
    } else {
      saveStatus.style.color = "#c00";
      saveStatus.textContent = `Backend error ${resp.status}`;
    }
  } catch (e) {
    saveStatus.style.color = "#c00";
    saveStatus.textContent = `Could not reach backend: ${e.message}`;
  }
});
