// Runs in the page's MAIN world — sets the sentinel that App.tsx checks via extensionInstalled().
// Cannot use chrome.* APIs here (MAIN world has no extension context).
window.__cartsavvyExtension = { version: '1.0.0' };
